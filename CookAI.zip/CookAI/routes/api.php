<?php

namespace Routes;

use App\Controllers\{
    HomeController,
    RecipeController,
    AIController,
    AdminController,
    AuthController,
    SocialController,
    CommunityController,
    ChallengeController
};
use Core\Database;
use Core\Router;

class ApiRouter
{
    private Router $router;
    private Database $db;

    public function __construct(Router $router, Database $db)
    {
        $this->router = $router;
        $this->db = $db;
    }

    /**
     * Регистрация всех маршрутов API
     */
    public function register()
    {
        // ===== ПУБЛИЧНЫЕ МАРШРУТЫ =====
        
        // HOME
        $this->router->get('/api/recipes', fn() => $this->handleController(HomeController::class, 'getRecipesApi'));
        $this->router->get('/api/recipes/popular', fn() => $this->handleController(HomeController::class, 'getPopularRecipes'));
        $this->router->get('/api/recipes/diet/:diet', fn($diet) => $this->handleController(HomeController::class, 'getRecipesByDiet', $diet));
        $this->router->get('/api/search', fn() => $this->handleController(HomeController::class, 'search'));

        // RECIPES
        $this->router->get('/api/recipe/:id', fn($id) => $this->handleController(RecipeController::class, 'show', $id));
        $this->router->get('/api/recipe/:id/comments', fn($id) => $this->handleController(RecipeController::class, 'getComments', $id));

        // ===== АУТЕНТИФИКАЦИЯ =====
        $this->router->post('/api/auth/login', fn() => $this->handleController(AuthController::class, 'login'));
        $this->router->post('/api/auth/register', fn() => $this->handleController(AuthController::class, 'register'));
        $this->router->post('/api/auth/logout', fn() => $this->handleController(AuthController::class, 'logout'));
        $this->router->post('/api/auth/forgot-password', fn() => $this->handleController(AuthController::class, 'forgotPassword'));
        $this->router->post('/api/auth/reset-password', fn() => $this->handleController(AuthController::class, 'resetPassword'));
        $this->router->post('/api/auth/refresh', fn() => $this->handleController(AuthController::class, 'refreshToken'));

        // ===== ЗАЩИЩЁННЫЕ МАРШРУТЫ (требуется авторизация) =====

        // RECIPES
        $this->router->post('/api/recipe', fn() => $this->requireAuth(fn() => 
            $this->handleController(RecipeController::class, 'store')));
        $this->router->put('/api/recipe/:id', fn($id) => $this->requireAuth(fn() =>
            $this->handleController(RecipeController::class, 'update', $id)));
        $this->router->delete('/api/recipe/:id', fn($id) => $this->requireAuth(fn() =>
            $this->handleController(RecipeController::class, 'delete', $id)));
        
        // FAVORITES
        $this->router->post('/api/recipe/:id/favorite', fn($id) => $this->requireAuth(fn() =>
            $this->handleController(RecipeController::class, 'addToFavorite', $id)));
        $this->router->delete('/api/recipe/:id/favorite', fn($id) => $this->requireAuth(fn() =>
            $this->handleController(RecipeController::class, 'removeFromFavorite', $id)));
        $this->router->get('/api/favorites', fn() => $this->requireAuth(fn() =>
            $this->handleController(RecipeController::class, 'getFavorites')));

        // COMMENTS
        $this->router->post('/api/recipe/:id/comment', fn($id) => $this->requireAuth(fn() =>
            $this->handleController(RecipeController::class, 'addComment', $id)));
        $this->router->delete('/api/comment/:id', fn($id) => $this->requireAuth(fn() =>
            $this->handleController(RecipeController::class, 'deleteComment', $id)));

        // ===== AI ИНСТРУМЕНТЫ =====
        $this->router->post('/api/ai/generate-recipe', fn() => $this->requireAuth(fn() =>
            $this->handleController(AIController::class, 'generateRecipe')));
        $this->router->post('/api/ai/scan-food', fn() => $this->requireAuth(fn() =>
            $this->handleController(AIController::class, 'scanFood')));
        $this->router->post('/api/ai/meal-plan', fn() => $this->requireAuth(fn() =>
            $this->handleController(AIController::class, 'generateMealPlan')));
        $this->router->post('/api/ai/advice', fn() => $this->requireAuth(fn() =>
            $this->handleController(AIController::class, 'adviceChat')));

        // ===== СОЦИАЛЬНЫЕ ФУНКЦИИ =====
        
        // ДРУЗЬЯ
        $this->router->post('/api/friend/add/:id', fn($id) => $this->requireAuth(fn() =>
            $this->handleController(SocialController::class, 'addFriend', $id)));
        $this->router->post('/api/friend/accept/:id', fn($id) => $this->requireAuth(fn() =>
            $this->handleController(SocialController::class, 'acceptFriend', $id)));
        $this->router->post('/api/friend/reject/:id', fn($id) => $this->requireAuth(fn() =>
            $this->handleController(SocialController::class, 'rejectFriend', $id)));
        $this->router->delete('/api/friend/:id', fn($id) => $this->requireAuth(fn() =>
            $this->handleController(SocialController::class, 'removeFriend', $id)));
        $this->router->get('/api/friends', fn() => $this->requireAuth(fn() =>
            $this->handleController(SocialController::class, 'getFriends')));
        $this->router->get('/api/friend-requests', fn() => $this->requireAuth(fn() =>
            $this->handleController(SocialController::class, 'getFriendRequests')));

        // СООБЩЕНИЯ
        $this->router->post('/api/message/send/:id', fn($id) => $this->requireAuth(fn() =>
            $this->handleController(SocialController::class, 'sendMessage', $id)));
        $this->router->get('/api/messages/:id', fn($id) => $this->requireAuth(fn() =>
            $this->handleController(SocialController::class, 'getConversation', $id)));
        $this->router->get('/api/chat/contacts', fn() => $this->requireAuth(fn() =>
            $this->handleController(SocialController::class, 'getChatContacts')));

        // ПРОФИЛЬ
        $this->router->get('/api/profile', fn() => $this->requireAuth(fn() =>
            $this->handleController(SocialController::class, 'getProfile')));
        $this->router->put('/api/profile', fn() => $this->requireAuth(fn() =>
            $this->handleController(SocialController::class, 'updateProfile')));
        $this->router->get('/api/profile/:username', fn($username) =>
            $this->handleController(SocialController::class, 'getPublicProfile', $username));

        // ===== СООБЩЕСТВА =====
        $this->router->get('/api/communities', fn() =>
            $this->handleController(CommunityController::class, 'list'));
        $this->router->get('/api/community/:id', fn($id) =>
            $this->handleController(CommunityController::class, 'show', $id));
        $this->router->post('/api/community', fn() => $this->requireAuth(fn() =>
            $this->handleController(CommunityController::class, 'create')));
        $this->router->put('/api/community/:id', fn($id) => $this->requireAuth(fn() =>
            $this->handleController(CommunityController::class, 'update', $id)));
        $this->router->delete('/api/community/:id', fn($id) => $this->requireAuth(fn() =>
            $this->handleController(CommunityController::class, 'delete', $id)));

        // ЧЛЕНЫ СООБЩЕСТВА
        $this->router->post('/api/community/:id/join', fn($id) => $this->requireAuth(fn() =>
            $this->handleController(CommunityController::class, 'joinCommunity', $id)));
        $this->router->post('/api/community/:id/leave', fn($id) => $this->requireAuth(fn() =>
            $this->handleController(CommunityController::class, 'leaveCommunity', $id)));
        $this->router->get('/api/community/:id/members', fn($id) =>
            $this->handleController(CommunityController::class, 'getMembers', $id));

        // ===== ЧЕЛЛЕНДЖИ =====
        $this->router->get('/api/challenges', fn() =>
            $this->handleController(ChallengeController::class, 'list'));
        $this->router->get('/api/challenge/:id', fn($id) =>
            $this->handleController(ChallengeController::class, 'show', $id));
        $this->router->post('/api/challenge/:id/join', fn($id) => $this->requireAuth(fn() =>
            $this->handleController(ChallengeController::class, 'join', $id)));
        $this->router->post('/api/challenge/:id/complete', fn($id) => $this->requireAuth(fn() =>
            $this->handleController(ChallengeController::class, 'complete', $id)));

        // ===== АДМИНИСТРАТОР =====

        // ДЭШБОРД
        $this->router->get('/api/admin/stats', fn() => $this->requireAdmin(fn() =>
            $this->handleController(AdminController::class, 'getStats')));
        
        // ПОЛЬЗОВАТЕЛИ
        $this->router->get('/api/admin/users', fn() => $this->requireAdmin(fn() =>
            $this->handleController(AdminController::class, 'listUsers')));
        $this->router->put('/api/admin/user/:id', fn($id) => $this->requireAdmin(fn() =>
            $this->handleController(AdminController::class, 'updateUser', $id)));
        $this->router->delete('/api/admin/user/:id', fn($id) => $this->requireAdmin(fn() =>
            $this->handleController(AdminController::class, 'deleteUser', $id)));

        // РЕЦЕПТЫ
        $this->router->get('/api/admin/recipes', fn() => $this->requireAdmin(fn() =>
            $this->handleController(AdminController::class, 'listRecipes')));
        $this->router->post('/api/admin/recipe/:id/toggle', fn($id) => $this->requireAdmin(fn() =>
            $this->handleController(AdminController::class, 'toggleRecipeStatus', $id)));
        $this->router->delete('/api/admin/recipe/:id', fn($id) => $this->requireAdmin(fn() =>
            $this->handleController(AdminController::class, 'deleteRecipe', $id)));

        // ЧЕЛЛЕНДЖИ
        $this->router->post('/api/admin/challenge', fn() => $this->requireAdmin(fn() =>
            $this->handleController(AdminController::class, 'createChallenge')));
        $this->router->put('/api/admin/challenge/:id', fn($id) => $this->requireAdmin(fn() =>
            $this->handleController(AdminController::class, 'updateChallenge', $id)));
        $this->router->delete('/api/admin/challenge/:id', fn($id) => $this->requireAdmin(fn() =>
            $this->handleController(AdminController::class, 'deleteChallenge', $id)));

        // ЖАЛОБЫ
        $this->router->get('/api/admin/reports', fn() => $this->requireAdmin(fn() =>
            $this->handleController(AdminController::class, 'listReports')));
        $this->router->post('/api/admin/report/:id/resolve', fn($id) => $this->requireAdmin(fn() =>
            $this->handleController(AdminController::class, 'resolveReport', $id)));
        $this->router->post('/api/admin/report/:id/reject', fn($id) => $this->requireAdmin(fn() =>
            $this->handleController(AdminController::class, 'rejectReport', $id)));

        // НАСТРОЙКИ
        $this->router->get('/api/admin/settings', fn() => $this->requireAdmin(fn() =>
            $this->handleController(AdminController::class, 'getSettings')));
        $this->router->put('/api/admin/settings', fn() => $this->requireAdmin(fn() =>
            $this->handleController(AdminController::class, 'updateSettings')));

        // ЛОГИ
        $this->router->get('/api/admin/logs', fn() => $this->requireAdmin(fn() =>
            $this->handleController(AdminController::class, 'getLogs')));
        $this->router->delete('/api/admin/logs', fn() => $this->requireAdmin(fn() =>
            $this->handleController(AdminController::class, 'clearLogs')));
    }

    /**
     * Обработать контроллер
     */
    private function handleController($controllerClass, $method, ...$params)
    {
        $controller = new $controllerClass($this->db);
        return call_user_func_array([$controller, $method], $params);
    }

    /**
     * Проверить авторизацию
     */
    private function requireAuth($callback)
    {
        if (!isset($_SESSION['user'])) {
            http_response_code(401);
            return json_encode(['error' => 'Unauthorized']);
        }
        return $callback();
    }

    /**
     * Проверить права администратора
     */
    private function requireAdmin($callback)
    {
        if (!isset($_SESSION['user']) || $_SESSION['user']['role'] !== 'admin') {
            http_response_code(403);
            return json_encode(['error' => 'Forbidden']);
        }
        return $callback();
    }
}
?>