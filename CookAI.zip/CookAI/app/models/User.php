<?php

namespace App\Models;

use Core\Database;

class User
{
    private Database $db;
    protected $table = 'users';

    public function __construct(Database $db)
    {
        $this->db = $db;
    }

    /**
     * Получить пользователя по ID
     */
    public function findById($id)
    {
        return $this->db->queryOne(
            "SELECT * FROM {$this->table} WHERE id = :id",
            ['id' => (int)$id]
        );
    }

    /**
     * Получить пользователя по username
     */
    public function findByUsername($username)
    {
        return $this->db->queryOne(
            "SELECT * FROM {$this->table} WHERE username = :username",
            ['username' => $username]
        );
    }

    /**
     * Получить пользователя по email
     */
    public function findByEmail($email)
    {
        return $this->db->queryOne(
            "SELECT * FROM {$this->table} WHERE email = :email",
            ['email' => $email]
        );
    }

    /**
     * Создать нового пользователя
     */
    public function create($data)
    {
        $sql = "INSERT INTO {$this->table} 
                (username, email, password_hash, full_name, diet_preference, daily_calories_goal)
                VALUES (:username, :email, :password_hash, :full_name, :diet_preference, :daily_calories_goal)";

        $this->db->execute($sql, [
            'username' => $data['username'],
            'email' => $data['email'],
            'password_hash' => password_hash($data['password'], PASSWORD_BCRYPT),
            'full_name' => $data['full_name'] ?? '',
            'diet_preference' => $data['diet_preference'] ?? 'omnivore',
            'daily_calories_goal' => $data['daily_calories_goal'] ?? 2000
        ]);

        return $this->db->lastInsertId();
    }

    /**
     * Обновить пользователя
     */
    public function update($id, $data)
    {
        $allowed = ['full_name', 'bio', 'avatar_url', 'diet_preference', 'daily_calories_goal'];
        $updates = [];
        $params = ['id' => (int)$id];

        foreach ($allowed as $field) {
            if (isset($data[$field])) {
                $updates[] = "$field = :$field";
                $params[$field] = $data[$field];
            }
        }

        if (empty($updates)) {
            return false;
        }

        $sql = "UPDATE {$this->table} SET " . implode(', ', $updates) . " WHERE id = :id";
        return $this->db->execute($sql, $params);
    }

    /**
     * Изменить пароль
     */
    public function changePassword($id, $oldPassword, $newPassword)
    {
        $user = $this->findById($id);

        if (!$user || !password_verify($oldPassword, $user['password_hash'])) {
            return false;
        }

        $sql = "UPDATE {$this->table} SET password_hash = :password WHERE id = :id";
        return $this->db->execute($sql, [
            'password' => password_hash($newPassword, PASSWORD_BCRYPT),
            'id' => (int)$id
        ]);
    }

    /**
     * Проверить пароль
     */
    public function verifyPassword($id, $password)
    {
        $user = $this->findById($id);
        return $user && password_verify($password, $user['password_hash']);
    }

    /**
     * Получить профиль пользователя с дополнительной информацией
     */
    public function getProfile($id)
    {
        $user = $this->findById($id);

        if (!$user) {
            return null;
        }

        // Получить статистику пользователя
        $stats = $this->db->queryOne(
            "SELECT 
                (SELECT COUNT(*) FROM recipes WHERE user_id = :id) as total_recipes,
                (SELECT COUNT(*) FROM favorites WHERE user_id = :id) as total_favorites,
                (SELECT COUNT(*) FROM friends WHERE user_id = :id AND status = 'accepted') as total_friends,
                (SELECT COUNT(*) FROM community_members WHERE user_id = :id) as total_communities,
                (SELECT COUNT(DISTINCT challenge_id) FROM user_challenges WHERE user_id = :id AND completed_at IS NOT NULL) as completed_challenges
             FROM users WHERE id = :id",
            ['id' => (int)$id]
        );

        return array_merge($user, $stats ?? []);
    }

    /**
     * Получить топ пользователей по активности
     */
    public function getTopUsers($limit = 10)
    {
        return $this->db->query(
            "SELECT u.id, u.username, u.avatar_url, u.bio,
                    COUNT(DISTINCT r.id) as recipe_count,
                    COUNT(DISTINCT f.id) as follower_count
             FROM {$this->table} u
             LEFT JOIN recipes r ON u.id = r.user_id
             LEFT JOIN friends f ON u.id = f.friend_id AND f.status = 'accepted'
             WHERE u.is_active = TRUE
             GROUP BY u.id
             ORDER BY recipe_count DESC
             LIMIT :limit",
            ['limit' => $limit]
        );
    }

    /**
     * Активировать/деактивировать пользователя
     */
    public function toggleActive($id, $isActive = null)
    {
        $user = $this->findById($id);

        if (!$user) {
            return false;
        }

        $newStatus = $isActive !== null ? (int)$isActive : !$user['is_active'];

        return $this->db->execute(
            "UPDATE {$this->table} SET is_active = :is_active WHERE id = :id",
            ['is_active' => $newStatus, 'id' => (int)$id]
        );
    }

    /**
     * Получить количество пользователей
     */
    public function getTotalCount()
    {
        $result = $this->db->queryOne("SELECT COUNT(*) as count FROM {$this->table}");
        return $result['count'] ?? 0;
    }

    /**
     * Поиск пользователей
     */
    public function search($query, $limit = 20)
    {
        return $this->db->query(
            "SELECT id, username, avatar_url, bio 
             FROM {$this->table}
             WHERE (username LIKE :query OR full_name LIKE :query)
             AND is_active = TRUE
             LIMIT :limit",
            ['query' => '%' . $query . '%', 'limit' => $limit]
        );
    }

    /**
     * Получить активных пользователей (за последние N дней)
     */
    public function getActiveUsers($days = 7)
    {
        return $this->db->query(
            "SELECT DISTINCT u.* FROM {$this->table} u
             WHERE u.updated_at >= DATE_SUB(NOW(), INTERVAL :days DAY)
             ORDER BY u.updated_at DESC",
            ['days' => (int)$days]
        );
    }

    /**
     * Удалить пользователя (мягкое удаление)
     */
    public function softDelete($id)
    {
        return $this->db->execute(
            "UPDATE {$this->table} SET is_active = FALSE WHERE id = :id",
            ['id' => (int)$id]
        );
    }

    /**
     * Получить последних зарегистрированных пользователей
     */
    public function getNewUsers($limit = 10)
    {
        return $this->db->query(
            "SELECT id, username, email, full_name, avatar_url, created_at
             FROM {$this->table}
             WHERE is_active = TRUE
             ORDER BY created_at DESC
             LIMIT :limit",
            ['limit' => $limit]
        );
    }
}
?>