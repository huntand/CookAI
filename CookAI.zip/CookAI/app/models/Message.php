<?php

namespace App\Models;

use Core\Database;

class Message
{
    private Database $db;
    protected $table = 'messages';

    public function __construct(Database $db)
    {
        $this->db = $db;
    }

    /**
     * Отправить сообщение
     */
    public function send($fromId, $toId, $text)
    {
        if ($fromId == $toId) {
            return false;
        }

        return $this->db->execute(
            "INSERT INTO {$this->table} (from_id, to_id, message_text) 
             VALUES (:from_id, :to_id, :text)",
            [
                'from_id' => (int)$fromId,
                'to_id' => (int)$toId,
                'text' => $text
            ]
        );
    }

    /**
     * Получить сообщения между пользователями
     */
    public function getConversation($userId1, $userId2, $limit = 50, $offset = 0)
    {
        return $this->db->query(
            "SELECT m.*, u.username, u.avatar_url
             FROM {$this->table} m
             JOIN users u ON m.from_id = u.id
             WHERE (m.from_id = :user1 AND m.to_id = :user2) OR
                   (m.from_id = :user2 AND m.to_id = :user1)
             ORDER BY m.created_at DESC
             LIMIT :limit OFFSET :offset",
            [
                'user1' => (int)$userId1,
                'user2' => (int)$userId2,
                'limit' => $limit,
                'offset' => $offset
            ]
        );
    }

    /**
     * Получить входящие сообщения
     */
    public function getInbox($userId, $limit = 50, $offset = 0)
    {
        return $this->db->query(
            "SELECT m.*, u.username, u.avatar_url,
                    (SELECT COUNT(*) FROM {$this->table} m2 
                     WHERE m2.from_id = m.from_id AND m2.to_id = :user_id AND m2.is_read = FALSE) as unread_count
             FROM {$this->table} m
             JOIN users u ON m.from_id = u.id
             WHERE m.to_id = :user_id
             GROUP BY m.from_id
             ORDER BY m.created_at DESC
             LIMIT :limit OFFSET :offset",
            ['user_id' => (int)$userId, 'limit' => $limit, 'offset' => $offset]
        );
    }

    /**
     * Получить исходящие сообщения
     */
    public function getSentMessages($userId, $limit = 50, $offset = 0)
    {
        return $this->db->query(
            "SELECT m.*, u.username, u.avatar_url
             FROM {$this->table} m
             JOIN users u ON m.to_id = u.id
             WHERE m.from_id = :user_id
             ORDER BY m.created_at DESC
             LIMIT :limit OFFSET :offset",
            ['user_id' => (int)$userId, 'limit' => $limit, 'offset' => $offset]
        );
    }

    /**
     * Отметить сообщение как прочитанное
     */
    public function markAsRead($messageId)
    {
        return $this->db->execute(
            "UPDATE {$this->table} SET is_read = TRUE WHERE id = :id",
            ['id' => (int)$messageId]
        );
    }

    /**
     * Отметить все сообщения от пользователя как прочитанные
     */
    public function markConversationAsRead($fromId, $toId)
    {
        return $this->db->execute(
            "UPDATE {$this->table} SET is_read = TRUE 
             WHERE from_id = :from_id AND to_id = :to_id AND is_read = FALSE",
            ['from_id' => (int)$fromId, 'to_id' => (int)$toId]
        );
    }

    /**
     * Получить количество непрочитанных сообщений
     */
    public function getUnreadCount($userId)
    {
        $result = $this->db->queryOne(
            "SELECT COUNT(*) as count FROM {$this->table} WHERE to_id = :user_id AND is_read = FALSE",
            ['user_id' => (int)$userId]
        );
        return $result['count'] ?? 0;
    }

    /**
     * Получить непрочитанные сообщения от пользователя
     */
    public function getUnreadFromUser($fromId, $toId)
    {
        return $this->db->query(
            "SELECT * FROM {$this->table}
             WHERE from_id = :from_id AND to_id = :to_id AND is_read = FALSE
             ORDER BY created_at ASC",
            ['from_id' => (int)$fromId, 'to_id' => (int)$toId]
        );
    }

    /**
     * Удалить сообщение
     */
    public function delete($messageId)
    {
        return $this->db->execute(
            "DELETE FROM {$this->table} WHERE id = :id",
            ['id' => (int)$messageId]
        );
    }

    /**
     * Получить последние контакты
     */
    public function getRecentContacts($userId, $limit = 20)
    {
        return $this->db->query(
            "SELECT DISTINCT 
                CASE 
                    WHEN from_id = :user_id THEN to_id 
                    ELSE from_id 
                END as contact_id,
                u.username, u.avatar_url,
                MAX(m.created_at) as last_message_at,
                (SELECT COUNT(*) FROM {$this->table} m2 
                 WHERE ((m2.from_id = contact_id AND m2.to_id = :user_id) OR 
                        (m2.from_id = :user_id AND m2.to_id = contact_id)) AND 
                       m2.id > MAX(m.id)) as has_new
             FROM {$this->table} m
             JOIN users u ON u.id = CASE 
                                        WHEN from_id = :user_id THEN to_id 
                                        ELSE from_id 
                                    END
             WHERE from_id = :user_id OR to_id = :user_id
             GROUP BY contact_id, u.id
             ORDER BY last_message_at DESC
             LIMIT :limit",
            ['user_id' => (int)$userId, 'limit' => $limit]
        );
    }
}
?>