<?php

namespace App\Models;

use Core\Database;

class Favorite
{
    private Database $db;
    protected $table = 'favorites';

    public function __construct(Database $db)
    {
        $this->db = $db;
    }

    /**
     * Добавить в избранное
     */
    public function add($userId, $recipeId)
    {
        // Проверить наличие
        $exists = $this->db->queryOne(
            "SELECT id FROM {$this->table} WHERE user_id = :user_id AND recipe_id = :recipe_id",
            ['user_id' => (int)$userId, 'recipe_id' => (int)$recipeId]
        );

        if ($exists) {
            return false;
        }

        return $this->db->execute(
            "INSERT INTO {$this->table} (user_id, recipe_id) VALUES (:user_id, :recipe_id)",
            ['user_id' => (int)$userId, 'recipe_id' => (int)$recipeId]
        );
    }

    /**
     * Удалить из избранного
     */
    public function remove($userId, $recipeId)
    {
        return $this->db->execute(
            "DELETE FROM {$this->table} WHERE user_id = :user_id AND recipe_id = :recipe_id",
            ['user_id' => (int)$userId, 'recipe_id' => (int)$recipeId]
        );
    }

    /**
     * Получить избранное пользователя
     */
    public function getUserFavorites($userId, $limit = 50, $offset = 0)
    {
        return $this->db->query(
            "SELECT r.*, u.username, u.avatar_url
             FROM {$this->table} f
             JOIN recipes r ON f.recipe_id = r.id
             JOIN users u ON r.user_id = u.id
             WHERE f.user_id = :user_id AND r.is_published = TRUE
             ORDER BY f.created_at DESC
             LIMIT :limit OFFSET :offset",
            ['user_id' => (int)$userId, 'limit' => $limit, 'offset' => $offset]
        );
    }

    /**
     * Проверить, в избранном ли рецепт
     */
    public function isFavorite($userId, $recipeId)
    {
        $result = $this->db->queryOne(
            "SELECT id FROM {$this->table} WHERE user_id = :user_id AND recipe_id = :recipe_id",
            ['user_id' => (int)$userId, 'recipe_id' => (int)$recipeId]
        );
        return $result !== null;
    }

    /**
     * Получить количество избранных рецептов
     */
    public function getUserFavoritesCount($userId)
    {
        $result = $this->db->queryOne(
            "SELECT COUNT(*) as count FROM {$this->table} WHERE user_id = :user_id",
            ['user_id' => (int)$userId]
        );
        return $result['count'] ?? 0;
    }

    /**
     * Получить количество избранных определённого рецепта
     */
    public function getRecipeFavoritesCount($recipeId)
    {
        $result = $this->db->queryOne(
            "SELECT COUNT(*) as count FROM {$this->table} WHERE recipe_id = :recipe_id",
            ['recipe_id' => (int)$recipeId]
        );
        return $result['count'] ?? 0;
    }

    /**
     * Получить топ избранных рецептов
     */
    public function getPopularRecipes($limit = 10)
    {
        return $this->db->query(
            "SELECT r.*, u.username, COUNT(f.id) as favorites_count
             FROM {$this->table} f
             JOIN recipes r ON f.recipe_id = r.id
             JOIN users u ON r.user_id = u.id
             WHERE r.is_published = TRUE
             GROUP BY r.id
             ORDER BY COUNT(f.id) DESC
             LIMIT :limit",
            ['limit' => $limit]
        );
    }

    /**
     * Удалить все избранное пользователя
     */
    public function clearUserFavorites($userId)
    {
        return $this->db->execute(
            "DELETE FROM {$this->table} WHERE user_id = :user_id",
            ['user_id' => (int)$userId]
        );
    }
}
?>