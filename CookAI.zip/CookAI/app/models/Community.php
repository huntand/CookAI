<?php

namespace App\Models;

use Core\Database;

class Community
{
    private Database $db;
    protected $table = 'communities';

    public function __construct(Database $db)
    {
        $this->db = $db;
    }

    /**
     * Получить сообщество по ID
     */
    public function findById($id)
    {
        $community = $this->db->queryOne(
            "SELECT c.*, u.username as admin_name, u.avatar_url as admin_avatar
             FROM {$this->table} c
             JOIN users u ON c.admin_id = u.id
             WHERE c.id = :id",
            ['id' => (int)$id]
        );

        if ($community) {
            $community['is_member'] = false; // Будет определено в контроллере
            $community['members_count'] = $this->getMembersCount($id);
        }

        return $community;
    }

    /**
     * Создать сообщество
     */
    public function create($data)
    {
        $sql = "INSERT INTO {$this->table}
                (name, description, category, admin_id, cover_image, is_active)
                VALUES
                (:name, :description, :category, :admin_id, :cover_image, 1)";

        $this->db->execute($sql, [
            'name' => $data['name'],
            'description' => $data['description'] ?? '',
            'category' => $data['category'] ?? null,
            'admin_id' => $data['admin_id'],
            'cover_image' => $data['cover_image'] ?? null
        ]);

        $communityId = $this->db->lastInsertId();

        // Добавить админа как члена
        $this->addMember($communityId, $data['admin_id'], 'moderator');

        return $communityId;
    }

    /**
     * Обновить сообщество
     */
    public function update($id, $data)
    {
        $allowed = ['name', 'description', 'category', 'cover_image', 'is_active'];
        $updates = [];
        $params = ['id' => (int)$id];

        foreach ($allowed as $field) {
            if (isset($data[$field])) {
                $updates[] = "$field = :$field";
                $params[$field] = $data[$field];
            }
        }

        if (empty($updates)) {
            return false;
        }

        $sql = "UPDATE {$this->table} SET " . implode(', ', $updates) . " WHERE id = :id";
        return $this->db->execute($sql, $params);
    }

    /**
     * Удалить сообщество
     */
    public function delete($id)
    {
        return $this->db->execute(
            "DELETE FROM {$this->table} WHERE id = :id",
            ['id' => (int)$id]
        );
    }

    /**
     * Получить все сообщества
     */
    public function getAll($limit = 50, $offset = 0)
    {
        return $this->db->query(
            "SELECT c.*, u.username as admin_name, COUNT(DISTINCT cm.user_id) as members_count
             FROM {$this->table} c
             JOIN users u ON c.admin_id = u.id
             LEFT JOIN community_members cm ON c.id = cm.community_id
             WHERE c.is_active = TRUE
             GROUP BY c.id
             ORDER BY c.created_at DESC
             LIMIT :limit OFFSET :offset",
            ['limit' => $limit, 'offset' => $offset]
        );
    }

    /**
     * Получить сообщества по категории
     */
    public function getByCategory($category, $limit = 50)
    {
        return $this->db->query(
            "SELECT c.*, u.username as admin_name, COUNT(DISTINCT cm.user_id) as members_count
             FROM {$this->table} c
             JOIN users u ON c.admin_id = u.id
             LEFT JOIN community_members cm ON c.id = cm.community_id
             WHERE c.category = :category AND c.is_active = TRUE
             GROUP BY c.id
             ORDER BY c.created_at DESC
             LIMIT :limit",
            ['category' => $category, 'limit' => $limit]
        );
    }

    /**
     * Поиск сообществ
     */
    public function search($query, $limit = 20)
    {
        return $this->db->query(
            "SELECT c.*, u.username as admin_name, COUNT(DISTINCT cm.user_id) as members_count
             FROM {$this->table} c
             JOIN users u ON c.admin_id = u.id
             LEFT JOIN community_members cm ON c.id = cm.community_id
             WHERE c.is_active = TRUE AND
                   (c.name LIKE :query OR c.description LIKE :query)
             GROUP BY c.id
             ORDER BY c.created_at DESC
             LIMIT :limit",
            ['query' => '%' . $query . '%', 'limit' => $limit]
        );
    }

    /**
     * Добавить члена сообщества
     */
    public function addMember($communityId, $userId, $role = 'member')
    {
        // Проверить, не является ли уже членом
        $exists = $this->db->queryOne(
            "SELECT id FROM community_members WHERE community_id = :community_id AND user_id = :user_id",
            ['community_id' => (int)$communityId, 'user_id' => (int)$userId]
        );

        if ($exists) {
            return false;
        }

        return $this->db->execute(
            "INSERT INTO community_members (community_id, user_id, role) VALUES (:community_id, :user_id, :role)",
            [
                'community_id' => (int)$communityId,
                'user_id' => (int)$userId,
                'role' => $role
            ]
        );
    }

    /**
     * Удалить члена сообщества
     */
    public function removeMember($communityId, $userId)
    {
        return $this->db->execute(
            "DELETE FROM community_members WHERE community_id = :community_id AND user_id = :user_id",
            ['community_id' => (int)$communityId, 'user_id' => (int)$userId]
        );
    }

    /**
     * Получить членов сообщества
     */
    public function getMembers($communityId, $limit = 100)
    {
        return $this->db->query(
            "SELECT u.id, u.username, u.avatar_url, u.bio, cm.role, cm.joined_at
             FROM community_members cm
             JOIN users u ON cm.user_id = u.id
             WHERE cm.community_id = :community_id
             ORDER BY cm.joined_at DESC
             LIMIT :limit",
            ['community_id' => (int)$communityId, 'limit' => $limit]
        );
    }

    /**
     * Получить количество членов
     */
    public function getMembersCount($communityId)
    {
        $result = $this->db->queryOne(
            "SELECT COUNT(*) as count FROM community_members WHERE community_id = :community_id",
            ['community_id' => (int)$communityId]
        );
        return $result['count'] ?? 0;
    }

    /**
     * Проверить, является ли пользователь членом
     */
    public function isMember($communityId, $userId)
    {
        $result = $this->db->queryOne(
            "SELECT id FROM community_members WHERE community_id = :community_id AND user_id = :user_id",
            ['community_id' => (int)$communityId, 'user_id' => (int)$userId]
        );
        return $result !== null;
    }

    /**
     * Получить сообщества пользователя
     */
    public function getUserCommunities($userId, $limit = 50)
    {
        return $this->db->query(
            "SELECT c.*, u.username as admin_name
             FROM {$this->table} c
             JOIN users u ON c.admin_id = u.id
             JOIN community_members cm ON c.id = cm.community_id
             WHERE cm.user_id = :user_id AND c.is_active = TRUE
             ORDER BY cm.joined_at DESC
             LIMIT :limit",
            ['user_id' => (int)$userId, 'limit' => $limit]
        );
    }

    /**
     * Получить топ сообществ
     */
    public function getTop($limit = 10)
    {
        return $this->db->query(
            "SELECT c.*, u.username as admin_name, COUNT(DISTINCT cm.user_id) as members_count
             FROM {$this->table} c
             JOIN users u ON c.admin_id = u.id
             LEFT JOIN community_members cm ON c.id = cm.community_id
             WHERE c.is_active = TRUE
             GROUP BY c.id
             ORDER BY members_count DESC
             LIMIT :limit",
            ['limit' => $limit]
        );
    }
}
?>