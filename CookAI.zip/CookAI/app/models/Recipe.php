<?php

namespace App\Models;

use Core\Database;

class Recipe
{
    private Database $db;
    protected $table = 'recipes';

    public function __construct(Database $db)
    {
        $this->db = $db;
    }

    /**
     * Получить рецепт по ID
     */
    public function findById($id)
    {
        $recipe = $this->db->queryOne(
            "SELECT r.*, u.username, u.avatar_url, u.id as author_id 
             FROM {$this->table} r 
             JOIN users u ON r.user_id = u.id 
             WHERE r.id = :id",
            ['id' => (int)$id]
        );

        if ($recipe) {
            $recipe['ingredients'] = $this->parseJson($recipe['ingredients']);
            $recipe['instructions'] = $this->parseJson($recipe['instructions']);
        }

        return $recipe;
    }

    /**
     * Создать рецепт
     */
    public function create($data)
    {
        $sql = "INSERT INTO {$this->table}
                (user_id, title, description, image_url, prep_time, cook_time, servings,
                 difficulty, cuisine, diet_type, calories_per_serving, proteins, fats, carbs,
                 ingredients, instructions, is_published)
                VALUES
                (:user_id, :title, :description, :image_url, :prep_time, :cook_time, :servings,
                 :difficulty, :cuisine, :diet_type, :calories, :proteins, :fats, :carbs,
                 :ingredients, :instructions, :is_published)";

        $this->db->execute($sql, [
            'user_id' => $data['user_id'],
            'title' => $data['title'],
            'description' => $data['description'],
            'image_url' => $data['image_url'] ?? null,
            'prep_time' => $data['prep_time'],
            'cook_time' => $data['cook_time'],
            'servings' => $data['servings'] ?? 4,
            'difficulty' => $data['difficulty'] ?? 'medium',
            'cuisine' => $data['cuisine'] ?? null,
            'diet_type' => $data['diet_type'] ?? 'omnivore',
            'calories' => $data['calories_per_serving'] ?? 0,
            'proteins' => $data['proteins'] ?? 0,
            'fats' => $data['fats'] ?? 0,
            'carbs' => $data['carbs'] ?? 0,
            'ingredients' => is_array($data['ingredients']) ? json_encode($data['ingredients']) : $data['ingredients'],
            'instructions' => is_array($data['instructions']) ? json_encode($data['instructions']) : $data['instructions'],
            'is_published' => $data['is_published'] ?? 1
        ]);

        return $this->db->lastInsertId();
    }

    /**
     * Обновить рецепт
     */
    public function update($id, $data)
    {
        $allowed = ['title', 'description', 'image_url', 'prep_time', 'cook_time', 'servings',
                    'difficulty', 'cuisine', 'diet_type', 'calories_per_serving', 'proteins',
                    'fats', 'carbs', 'ingredients', 'instructions', 'is_published'];

        $updates = [];
        $params = ['id' => (int)$id];

        foreach ($allowed as $field) {
            if (isset($data[$field])) {
                if (in_array($field, ['ingredients', 'instructions'])) {
                    $value = is_array($data[$field]) ? json_encode($data[$field]) : $data[$field];
                } else {
                    $value = $data[$field];
                }

                $updates[] = "$field = :$field";
                $params[$field] = $value;
            }
        }

        if (empty($updates)) {
            return false;
        }

        $sql = "UPDATE {$this->table} SET " . implode(', ', $updates) . " WHERE id = :id";
        return $this->db->execute($sql, $params);
    }

    /**
     * Удалить рецепт
     */
    public function delete($id)
    {
        return $this->db->execute(
            "DELETE FROM {$this->table} WHERE id = :id",
            ['id' => (int)$id]
        );
    }

    /**
     * Получить рецепты пользователя
     */
    public function getUserRecipes($userId, $limit = 20, $offset = 0)
    {
        $recipes = $this->db->query(
            "SELECT r.*, 
                    (SELECT COUNT(*) FROM favorites WHERE recipe_id = r.id) as favorites_count,
                    (SELECT COUNT(*) FROM recipe_comments WHERE recipe_id = r.id) as comments_count
             FROM {$this->table} r
             WHERE r.user_id = :user_id
             ORDER BY r.created_at DESC
             LIMIT :limit OFFSET :offset",
            ['user_id' => (int)$userId, 'limit' => $limit, 'offset' => $offset]
        );

        return $this->parseJsonArrays($recipes);
    }

    /**
     * Получить популярные рецепты
     */
    public function getPopular($limit = 12)
    {
        $recipes = $this->db->query(
            "SELECT r.*, u.username, u.avatar_url,
                    (SELECT COUNT(*) FROM favorites WHERE recipe_id = r.id) as favorites_count
             FROM {$this->table} r
             JOIN users u ON r.user_id = u.id
             WHERE r.is_published = TRUE
             ORDER BY r.views_count DESC
             LIMIT :limit",
            ['limit' => $limit]
        );

        return $this->parseJsonArrays($recipes);
    }

    /**
     * Получить новые рецепты
     */
    public function getRecent($limit = 12)
    {
        $recipes = $this->db->query(
            "SELECT r.*, u.username, u.avatar_url,
                    (SELECT COUNT(*) FROM favorites WHERE recipe_id = r.id) as favorites_count
             FROM {$this->table} r
             JOIN users u ON r.user_id = u.id
             WHERE r.is_published = TRUE
             ORDER BY r.created_at DESC
             LIMIT :limit",
            ['limit' => $limit]
        );

        return $this->parseJsonArrays($recipes);
    }

    /**
     * Получить рецепты по диете
     */
    public function getByDiet($diet, $limit = 20, $offset = 0)
    {
        $recipes = $this->db->query(
            "SELECT r.*, u.username, u.avatar_url
             FROM {$this->table} r
             JOIN users u ON r.user_id = u.id
             WHERE r.diet_type = :diet AND r.is_published = TRUE
             ORDER BY r.created_at DESC
             LIMIT :limit OFFSET :offset",
            ['diet' => $diet, 'limit' => $limit, 'offset' => $offset]
        );

        return $this->parseJsonArrays($recipes);
    }

    /**
     * Поиск рецептов
     */
    public function search($query, $limit = 20)
    {
        $recipes = $this->db->query(
            "SELECT r.*, u.username, u.avatar_url,
                    (SELECT COUNT(*) FROM favorites WHERE recipe_id = r.id) as favorites_count
             FROM {$this->table} r
             JOIN users u ON r.user_id = u.id
             WHERE r.is_published = TRUE AND
                   (r.title LIKE :query OR r.description LIKE :query)
             ORDER BY r.created_at DESC
             LIMIT :limit",
            ['query' => '%' . $query . '%', 'limit' => $limit]
        );

        return $this->parseJsonArrays($recipes);
    }

    /**
     * Фильтрованный поиск
     */
    public function searchWithFilters($query, $filters = [], $limit = 20, $offset = 0)
    {
        $conditions = ["r.is_published = TRUE"];

        if ($query) {
            $conditions[] = "(r.title LIKE '%" . addslashes($query) . "%' OR r.description LIKE '%" . addslashes($query) . "%')";
        }

        if (!empty($filters['diet']) && in_array($filters['diet'], ['omnivore', 'vegetarian', 'vegan', 'keto', 'paleo'])) {
            $conditions[] = "r.diet_type = '" . $filters['diet'] . "'";
        }

        if (!empty($filters['difficulty']) && in_array($filters['difficulty'], ['easy', 'medium', 'hard'])) {
            $conditions[] = "r.difficulty = '" . $filters['difficulty'] . "'";
        }

        if (!empty($filters['max_time']) && is_numeric($filters['max_time'])) {
            $time = (int)$filters['max_time'];
            $conditions[] = "(r.prep_time + r.cook_time) <= $time";
        }

        if (!empty($filters['max_calories']) && is_numeric($filters['max_calories'])) {
            $calories = (int)$filters['max_calories'];
            $conditions[] = "r.calories_per_serving <= $calories";
        }

        $where = implode(' AND ', $conditions);

        $recipes = $this->db->query(
            "SELECT r.*, u.username, u.avatar_url,
                    (SELECT COUNT(*) FROM favorites WHERE recipe_id = r.id) as favorites_count
             FROM {$this->table} r
             JOIN users u ON r.user_id = u.id
             WHERE $where
             ORDER BY r.created_at DESC
             LIMIT :limit OFFSET :offset",
            ['limit' => $limit, 'offset' => $offset]
        );

        return $this->parseJsonArrays($recipes);
    }

    /**
     * Увеличить просмотры
     */
    public function incrementViews($id)
    {
        return $this->db->execute(
            "UPDATE {$this->table} SET views_count = views_count + 1 WHERE id = :id",
            ['id' => (int)$id]
        );
    }

    /**
     * Получить рейтинг рецепта
     */
    public function getRating($id)
    {
        return $this->db->queryOne(
            "SELECT COUNT(*) as count, AVG(rating) as average
             FROM recipe_comments
             WHERE recipe_id = :id AND rating IS NOT NULL",
            ['id' => (int)$id]
        );
    }

    /**
     * Получить комментарии к рецепту
     */
    public function getComments($id, $limit = 50)
    {
        return $this->db->query(
            "SELECT c.*, u.username, u.avatar_url
             FROM recipe_comments c
             JOIN users u ON c.user_id = u.id
             WHERE c.recipe_id = :id
             ORDER BY c.created_at DESC
             LIMIT :limit",
            ['id' => (int)$id, 'limit' => $limit]
        );
    }

    /**
     * Добавить комментарий
     */
    public function addComment($recipeId, $userId, $text, $rating = null)
    {
        return $this->db->execute(
            "INSERT INTO recipe_comments (recipe_id, user_id, comment_text, rating)
             VALUES (:recipe_id, :user_id, :text, :rating)",
            [
                'recipe_id' => (int)$recipeId,
                'user_id' => (int)$userId,
                'text' => $text,
                'rating' => $rating
            ]
        );
    }

    /**
     * Получить общее количество рецептов
     */
    public function getTotalCount()
    {
        $result = $this->db->queryOne("SELECT COUNT(*) as count FROM {$this->table} WHERE is_published = TRUE");
        return $result['count'] ?? 0;
    }

    /**
     * Парсить JSON строку
     */
    private function parseJson($json)
    {
        if (is_string($json)) {
            return json_decode($json, true) ?? [];
        }
        return $json ?? [];
    }

    /**
     * Парсить JSON в массиве рецептов
     */
    private function parseJsonArrays($recipes)
    {
        return array_map(function ($recipe) {
            $recipe['ingredients'] = $this->parseJson($recipe['ingredients']);
            $recipe['instructions'] = $this->parseJson($recipe['instructions']);
            return $recipe;
        }, $recipes);
    }
}
?>