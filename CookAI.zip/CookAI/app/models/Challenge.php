<?php

namespace App\Models;

use Core\Database;

class Challenge
{
    private Database $db;
    protected $table = 'challenges';

    public function __construct(Database $db)
    {
        $this->db = $db;
    }

    /**
     * Получить челленж по ID
     */
    public function findById($id)
    {
        return $this->db->queryOne(
            "SELECT * FROM {$this->table} WHERE id = :id",
            ['id' => (int)$id]
        );
    }

    /**
     * Создать челленж
     */
    public function create($data)
    {
        $sql = "INSERT INTO {$this->table}
                (title, description, image_url, start_date, end_date, difficulty, reward_points)
                VALUES
                (:title, :description, :image_url, :start_date, :end_date, :difficulty, :reward_points)";

        $this->db->execute($sql, [
            'title' => $data['title'],
            'description' => $data['description'] ?? '',
            'image_url' => $data['image_url'] ?? null,
            'start_date' => $data['start_date'],
            'end_date' => $data['end_date'],
            'difficulty' => $data['difficulty'] ?? 'medium',
            'reward_points' => $data['reward_points'] ?? 100
        ]);

        return $this->db->lastInsertId();
    }

    /**
     * Обновить челленж
     */
    public function update($id, $data)
    {
        $allowed = ['title', 'description', 'image_url', 'start_date', 'end_date', 'difficulty', 'reward_points'];
        $updates = [];
        $params = ['id' => (int)$id];

        foreach ($allowed as $field) {
            if (isset($data[$field])) {
                $updates[] = "$field = :$field";
                $params[$field] = $data[$field];
            }
        }

        if (empty($updates)) {
            return false;
        }

        $sql = "UPDATE {$this->table} SET " . implode(', ', $updates) . " WHERE id = :id";
        return $this->db->execute($sql, $params);
    }

    /**
     * Удалить челленж
     */
    public function delete($id)
    {
        return $this->db->execute(
            "DELETE FROM {$this->table} WHERE id = :id",
            ['id' => (int)$id]
        );
    }

    /**
     * Получить активные челленджи
     */
    public function getActive($limit = 10)
    {
        return $this->db->query(
            "SELECT c.*, COUNT(DISTINCT uc.user_id) as participants
             FROM {$this->table} c
             LEFT JOIN user_challenges uc ON c.id = uc.challenge_id
             WHERE c.start_date <= CURDATE() AND c.end_date >= CURDATE()
             GROUP BY c.id
             ORDER BY c.end_date ASC
             LIMIT :limit",
            ['limit' => $limit]
        );
    }

    /**
     * Получить предстоящие челленджи
     */
    public function getUpcoming($limit = 10)
    {
        return $this->db->query(
            "SELECT c.*, COUNT(DISTINCT uc.user_id) as participants
             FROM {$this->table} c
             LEFT JOIN user_challenges uc ON c.id = uc.challenge_id
             WHERE c.start_date > CURDATE()
             GROUP BY c.id
             ORDER BY c.start_date ASC
             LIMIT :limit",
            ['limit' => $limit]
        );
    }

    /**
     * Получить прошлые челленджи
     */
    public function getPast($limit = 10)
    {
        return $this->db->query(
            "SELECT c.*, COUNT(DISTINCT uc.user_id) as participants
             FROM {$this->table} c
             LEFT JOIN user_challenges uc ON c.id = uc.challenge_id
             WHERE c.end_date < CURDATE()
             GROUP BY c.id
             ORDER BY c.end_date DESC
             LIMIT :limit",
            ['limit' => $limit]
        );
    }

    /**
     * Присоединиться к челленджу
     */
    public function joinChallenge($challengeId, $userId)
    {
        // Проверить, не присоединен ли уже
        $exists = $this->db->queryOne(
            "SELECT id FROM user_challenges WHERE challenge_id = :challenge_id AND user_id = :user_id",
            ['challenge_id' => (int)$challengeId, 'user_id' => (int)$userId]
        );

        if ($exists) {
            return false;
        }

        return $this->db->execute(
            "INSERT INTO user_challenges (user_id, challenge_id, progress) VALUES (:user_id, :challenge_id, 0)",
            ['user_id' => (int)$userId, 'challenge_id' => (int)$challengeId]
        );
    }

    /**
     * Обновить прогресс
     */
    public function updateProgress($challengeId, $userId, $progress)
    {
        return $this->db->execute(
            "UPDATE user_challenges SET progress = :progress WHERE challenge_id = :challenge_id AND user_id = :user_id",
            [
                'progress' => min(100, max(0, (int)$progress)),
                'challenge_id' => (int)$challengeId,
                'user_id' => (int)$userId
            ]
        );
    }

    /**
     * Завершить челленж для пользователя
     */
    public function completeChallenge($challengeId, $userId)
    {
        return $this->db->execute(
            "UPDATE user_challenges SET completed_at = NOW(), progress = 100 
             WHERE challenge_id = :challenge_id AND user_id = :user_id",
            ['challenge_id' => (int)$challengeId, 'user_id' => (int)$userId]
        );
    }

    /**
     * Получить челленджи пользователя
     */
    public function getUserChallenges($userId, $status = 'active')
    {
        $whereClause = '';

        if ($status === 'active') {
            $whereClause = " AND c.start_date <= CURDATE() AND c.end_date >= CURDATE()";
        } elseif ($status === 'completed') {
            $whereClause = " AND uc.completed_at IS NOT NULL";
        }

        return $this->db->query(
            "SELECT c.*, uc.progress, uc.completed_at
             FROM user_challenges uc
             JOIN {$this->table} c ON uc.challenge_id = c.id
             WHERE uc.user_id = :user_id $whereClause
             ORDER BY c.start_date DESC",
            ['user_id' => (int)$userId]
        );
    }

    /**
     * Получить лидеров челленджа
     */
    public function getLeaders($challengeId, $limit = 10)
    {
        return $this->db->query(
            "SELECT u.id, u.username, u.avatar_url, uc.progress, uc.completed_at
             FROM user_challenges uc
             JOIN users u ON uc.user_id = u.id
             WHERE uc.challenge_id = :challenge_id
             ORDER BY uc.completed_at IS NULL, uc.completed_at ASC, uc.progress DESC
             LIMIT :limit",
            ['challenge_id' => (int)$challengeId, 'limit' => $limit]
        );
    }

    /**
     * Получить количество участников
     */
    public function getParticipantsCount($challengeId)
    {
        $result = $this->db->queryOne(
            "SELECT COUNT(DISTINCT user_id) as count FROM user_challenges WHERE challenge_id = :challenge_id",
            ['challenge_id' => (int)$challengeId]
        );
        return $result['count'] ?? 0;
    }

    /**
     * Проверить, участвует ли пользователь
     */
    public function isParticipant($challengeId, $userId)
    {
        $result = $this->db->queryOne(
            "SELECT id FROM user_challenges WHERE challenge_id = :challenge_id AND user_id = :user_id",
            ['challenge_id' => (int)$challengeId, 'user_id' => (int)$userId]
        );
        return $result !== null;
    }

    /**
     * Получить прогресс пользователя
     */
    public function getUserProgress($challengeId, $userId)
    {
        return $this->db->queryOne(
            "SELECT progress, completed_at FROM user_challenges 
             WHERE challenge_id = :challenge_id AND user_id = :user_id",
            ['challenge_id' => (int)$challengeId, 'user_id' => (int)$userId]
        );
    }
}
?>