<?php

namespace App\Models;

use Core\Database;

class Cookbook
{
    private Database $db;
    protected $table = 'cookbooks';

    public function __construct(Database $db)
    {
        $this->db = $db;
    }

    /**
     * Получить кулинарную книгу по ID
     */
    public function findById($id)
    {
        return $this->db->queryOne(
            "SELECT c.*, u.username, u.avatar_url
             FROM {$this->table} c
             JOIN users u ON c.user_id = u.id
             WHERE c.id = :id",
            ['id' => (int)$id]
        );
    }

    /**
     * Создать кулинарную книгу
     */
    public function create($data)
    {
        $sql = "INSERT INTO {$this->table}
                (user_id, title, description, cover_image, is_public)
                VALUES
                (:user_id, :title, :description, :cover_image, :is_public)";

        $this->db->execute($sql, [
            'user_id' => $data['user_id'],
            'title' => $data['title'],
            'description' => $data['description'] ?? '',
            'cover_image' => $data['cover_image'] ?? null,
            'is_public' => $data['is_public'] ?? 0
        ]);

        return $this->db->lastInsertId();
    }

    /**
     * Обновить кулинарную книгу
     */
    public function update($id, $data)
    {
        $allowed = ['title', 'description', 'cover_image', 'is_public'];
        $updates = [];
        $params = ['id' => (int)$id];

        foreach ($allowed as $field) {
            if (isset($data[$field])) {
                $updates[] = "$field = :$field";
                $params[$field] = $data[$field];
            }
        }

        if (empty($updates)) {
            return false;
        }

        $sql = "UPDATE {$this->table} SET " . implode(', ', $updates) . " WHERE id = :id";
        return $this->db->execute($sql, $params);
    }

    /**
     * Удалить кулинарную книгу
     */
    public function delete($id)
    {
        return $this->db->execute(
            "DELETE FROM {$this->table} WHERE id = :id",
            ['id' => (int)$id]
        );
    }

    /**
     * Получить книги пользователя
     */
    public function getUserCookbooks($userId, $limit = 50)
    {
        return $this->db->query(
            "SELECT c.*, COUNT(br.id) as recipes_count
             FROM {$this->table} c
             LEFT JOIN book_recipes br ON c.id = br.book_id
             WHERE c.user_id = :user_id
             GROUP BY c.id
             ORDER BY c.created_at DESC
             LIMIT :limit",
            ['user_id' => (int)$userId, 'limit' => $limit]
        );
    }

    /**
     * Добавить рецепт в книгу
     */
    public function addRecipe($bookId, $recipeId)
    {
        // Проверить наличие
        $exists = $this->db->queryOne(
            "SELECT id FROM book_recipes WHERE book_id = :book_id AND recipe_id = :recipe_id",
            ['book_id' => (int)$bookId, 'recipe_id' => (int)$recipeId]
        );

        if ($exists) {
            return false;
        }

        // Получить максимальную позицию
        $maxPosition = $this->db->queryOne(
            "SELECT MAX(position) as max_pos FROM book_recipes WHERE book_id = :book_id",
            ['book_id' => (int)$bookId]
        );

        $position = ($maxPosition['max_pos'] ?? 0) + 1;

        return $this->db->execute(
            "INSERT INTO book_recipes (book_id, recipe_id, position) VALUES (:book_id, :recipe_id, :position)",
            [
                'book_id' => (int)$bookId,
                'recipe_id' => (int)$recipeId,
                'position' => $position
            ]
        );
    }

    /**
     * Удалить рецепт из книги
     */
    public function removeRecipe($bookId, $recipeId)
    {
        return $this->db->execute(
            "DELETE FROM book_recipes WHERE book_id = :book_id AND recipe_id = :recipe_id",
            ['book_id' => (int)$bookId, 'recipe_id' => (int)$recipeId]
        );
    }

    /**
     * Получить рецепты книги
     */
    public function getRecipes($bookId, $limit = 100)
    {
        return $this->db->query(
            "SELECT r.*, br.position
             FROM book_recipes br
             JOIN recipes r ON br.recipe_id = r.id
             WHERE br.book_id = :book_id
             ORDER BY br.position ASC
             LIMIT :limit",
            ['book_id' => (int)$bookId, 'limit' => $limit]
        );
    }

    /**
     * Получить количество рецептов в книге
     */
    public function getRecipesCount($bookId)
    {
        $result = $this->db->queryOne(
            "SELECT COUNT(*) as count FROM book_recipes WHERE book_id = :book_id",
            ['book_id' => (int)$bookId]
        );
        return $result['count'] ?? 0;
    }

    /**
     * Получить публичные книги
     */
    public function getPublicCookbooks($limit = 50, $offset = 0)
    {
        return $this->db->query(
            "SELECT c.*, u.username, u.avatar_url, COUNT(br.id) as recipes_count
             FROM {$this->table} c
             JOIN users u ON c.user_id = u.id
             LEFT JOIN book_recipes br ON c.id = br.book_id
             WHERE c.is_public = TRUE
             GROUP BY c.id
             ORDER BY c.created_at DESC
             LIMIT :limit OFFSET :offset",
            ['limit' => $limit, 'offset' => $offset]
        );
    }

    /**
     * Поиск книг
     */
    public function search($query, $limit = 20)
    {
        return $this->db->query(
            "SELECT c.*, u.username, COUNT(br.id) as recipes_count
             FROM {$this->table} c
             JOIN users u ON c.user_id = u.id
             LEFT JOIN book_recipes br ON c.id = br.book_id
             WHERE c.is_public = TRUE AND (c.title LIKE :query OR c.description LIKE :query)
             GROUP BY c.id
             ORDER BY c.created_at DESC
             LIMIT :limit",
            ['query' => '%' . $query . '%', 'limit' => $limit]
        );
    }
}
?>