<?php

namespace App\Controllers;

use Core\Database;
use App\Services\YandexAIService;

class AIController
{
    private Database $db;
    private YandexAIService $aiService;

    public function __construct(Database $db)
    {
        $this->db = $db;
        $this->aiService = new YandexAIService();
    }

    /**
     * Генератор рецептов
     */
    public function generateRecipe()
    {
        if (!$this->isAuthorized()) {
            http_response_code(401);
            return json_encode(['error' => 'Unauthorized']);
        }

        $data = json_decode(file_get_contents('php://input'), true);

        if (!$data || !isset($data['diet'], $data['ingredients'])) {
            return json_encode(['error' => 'Invalid input']);
        }

        try {
            // Подготовка промта для AI
            $prompt = $this->buildRecipePrompt($data);

            // Получить ответ от Yandex GPT
            $response = $this->aiService->generateText($prompt);

            // Парсинг ответа (простой JSON-формат)
            $recipe = json_decode($response, true);

            if (!$recipe) {
                return json_encode(['error' => 'Failed to generate recipe']);
            }

            // Сохранить в БД
            $recipeId = $this->saveGeneratedRecipe($recipe);

            header('Content-Type: application/json');
            return json_encode([
                'success' => true,
                'recipe' => array_merge($recipe, ['id' => $recipeId])
            ]);
        } catch (\Exception $e) {
            header('Content-Type: application/json');
            return json_encode(['error' => $e->getMessage()]);
        }
    }

    /**
     * Сканер калорий по фото
     */
    public function scanFood()
    {
        if (!$this->isAuthorized()) {
            http_response_code(401);
            return json_encode(['error' => 'Unauthorized']);
        }

        if (!isset($_FILES['image'])) {
            return json_encode(['error' => 'No image provided']);
        }

        try {
            $imagePath = $this->uploadImage($_FILES['image']);

            // Отправить в Yandex Computer Vision
            $analysisResult = $this->aiService->analyzeFood($imagePath);

            // Сохранить результат в БД
            $this->db->execute(
                "INSERT INTO scanned_food 
                 (user_id, image_path, recognized_ingredients, calories, proteins, fats, carbs)
                 VALUES (:user_id, :image_path, :ingredients, :calories, :proteins, :fats, :carbs)",
                [
                    'user_id' => $_SESSION['user']['id'],
                    'image_path' => $imagePath,
                    'ingredients' => json_encode($analysisResult['ingredients']),
                    'calories' => $analysisResult['calories'],
                    'proteins' => $analysisResult['proteins'],
                    'fats' => $analysisResult['fats'],
                    'carbs' => $analysisResult['carbs']
                ]
            );

            header('Content-Type: application/json');
            return json_encode([
                'success' => true,
                'data' => $analysisResult
            ]);
        } catch (\Exception $e) {
            header('Content-Type: application/json');
            return json_encode(['error' => $e->getMessage()]);
        }
    }

    /**
     * Генератор меню на неделю
     */
    public function generateMealPlan()
    {
        if (!$this->isAuthorized()) {
            http_response_code(401);
            return json_encode(['error' => 'Unauthorized']);
        }

        $data = json_decode(file_get_contents('php://input'), true);

        if (!$data || !isset($data['goal'])) {
            return json_encode(['error' => 'Invalid input']);
        }

        try {
            $prompt = $this->buildMealPlanPrompt($data);
            $response = $this->aiService->generateText($prompt);
            $mealPlan = json_decode($response, true);

            header('Content-Type: application/json');
            return json_encode([
                'success' => true,
                'meal_plan' => $mealPlan
            ]);
        } catch (\Exception $e) {
            header('Content-Type: application/json');
            return json_encode(['error' => $e->getMessage()]);
        }
    }

    /**
     * Советник по готовке (чат)
     */
    public function adviceChat()
    {
        if (!$this->isAuthorized()) {
            http_response_code(401);
            return json_encode(['error' => 'Unauthorized']);
        }

        $data = json_decode(file_get_contents('php://input'), true);

        if (!isset($data['question'])) {
            return json_encode(['error' => 'No question provided']);
        }

        try {
            $prompt = "Ты помощник по кулинарии. Ответь на вопрос кратко и полезно:\n" . $data['question'];
            $response = $this->aiService->generateText($prompt);

            header('Content-Type: application/json');
            return json_encode([
                'success' => true,
                'answer' => $response
            ]);
        } catch (\Exception $e) {
            header('Content-Type: application/json');
            return json_encode(['error' => $e->getMessage()]);
        }
    }

    /**
     * Поиск рецептов по ингредиентам
     */
    public function findByIngredients()
    {
        $ingredients = $_POST['ingredients'] ?? [];

        if (empty($ingredients)) {
            return json_encode(['error' => 'No ingredients provided']);
        }

        try {
            // Построить запрос поиска
            $conditions = array_map(
                fn($ing) => "ingredients LIKE '%" . addslashes($ing) . "%'",
                $ingredients
            );

            $recipes = $this->db->query(
                "SELECT r.*, u.username 
                 FROM recipes r 
                 JOIN users u ON r.user_id = u.id 
                 WHERE r.is_published = TRUE AND (" . implode(' OR ', $conditions) . ")
                 LIMIT 20"
            );

            header('Content-Type: application/json');
            return json_encode([
                'success' => true,
                'recipes' => $recipes
            ]);
        } catch (\Exception $e) {
            header('Content-Type: application/json');
            return json_encode(['error' => $e->getMessage()]);
        }
    }

    /**
     * Генерация обложки для кулинарной книги
     */
    public function generateCookbookCover()
    {
        if (!$this->isAuthorized()) {
            http_response_code(401);
            return json_encode(['error' => 'Unauthorized']);
        }

        $data = json_decode(file_get_contents('php://input'), true);

        if (!isset($data['title'])) {
            return json_encode(['error' => 'No title provided']);
        }

        try {
            // Генерировать изображение через Yandex Image Generation
            $imageUrl = $this->aiService->generateImage($data['title']);

            header('Content-Type: application/json');
            return json_encode([
                'success' => true,
                'image_url' => $imageUrl
            ]);
        } catch (\Exception $e) {
            header('Content-Type: application/json');
            return json_encode(['error' => $e->getMessage()]);
        }
    }

    /**
     * Построить промт для генерации рецепта
     */
    private function buildRecipePrompt($data)
    {
        $ingredients = implode(', ', $data['ingredients']);
        $time = $data['time'] ?? 30;
        $diet = $data['diet'] ?? 'omnivore';

        return <<<PROMPT
Сгенерируй рецепт в формате JSON со следующими ограничениями:
- Тип диеты: $diet
- Максимальное время: $time минут
- Доступные ингредиенты: $ingredients

Формат JSON:
{
    "name": "Название рецепта",
    "description": "Краткое описание",
    "ingredients": ["ингредиент 1", "ингредиент 2"],
    "instructions": ["шаг 1", "шаг 2"],
    "prep_time": число,
    "cook_time": число,
    "servings": число,
    "nutrition": {
        "calories": число,
        "proteins": число,
        "fats": число,
        "carbs": число
    }
}
PROMPT;
    }

    /**
     * Построить промт для планирования меню
     */
    private function buildMealPlanPrompt($data)
    {
        $goal = $data['goal'] ?? 'balanced';
        $days = $data['days'] ?? 7;
        $calories = $data['calories'] ?? 2000;

        return <<<PROMPT
Создай план питания на $days дней:
- Цель: $goal
- Дневной калорийный лимит: $calories ккал
- Формат: JSON с массивом дней, каждый день содержит массив приёмов пищи (завтрак, обед, ужин)

JSON формат:
{
    "days": [
        {
            "date": "2026-05-28",
            "meals": {
                "breakfast": "название блюда",
                "lunch": "название блюда",
                "dinner": "название блюда"
            }
        }
    ]
}
PROMPT;
    }

    /**
     * Сохранить сгенерированный рецепт
     */
    private function saveGeneratedRecipe($recipe)
    {
        $this->db->execute(
            "INSERT INTO recipes 
             (user_id, title, description, prep_time, cook_time, servings, 
              ingredients, instructions, calories_per_serving, proteins, fats, carbs, is_published)
             VALUES (:user_id, :title, :description, :prep_time, :cook_time, :servings,
                     :ingredients, :instructions, :calories, :proteins, :fats, :carbs, 1)",
            [
                'user_id' => $_SESSION['user']['id'],
                'title' => $recipe['name'],
                'description' => $recipe['description'],
                'prep_time' => $recipe['prep_time'],
                'cook_time' => $recipe['cook_time'],
                'servings' => $recipe['servings'],
                'ingredients' => json_encode($recipe['ingredients']),
                'instructions' => json_encode($recipe['instructions']),
                'calories' => $recipe['nutrition']['calories'],
                'proteins' => $recipe['nutrition']['proteins'],
                'fats' => $recipe['nutrition']['fats'],
                'carbs' => $recipe['nutrition']['carbs']
            ]
        );

        return $this->db->lastInsertId();
    }

    /**
     * Загрузить изображение
     */
    private function uploadImage($file)
    {
        if (!$file || $file['error'] !== UPLOAD_ERR_OK) {
            throw new \Exception('Upload error');
        }

        $filename = uniqid('scan_') . '.' . pathinfo($file['name'], PATHINFO_EXTENSION);
        $uploadDir = __DIR__ . '/../../storage/uploads/scans/';

        if (!is_dir($uploadDir)) {
            mkdir($uploadDir, 0755, true);
        }

        if (!move_uploaded_file($file['tmp_name'], $uploadDir . $filename)) {
            throw new \Exception('Failed to save image');
        }

        return '/storage/uploads/scans/' . $filename;
    }

    /**
     * Проверить авторизацию
     */
    private function isAuthorized()
    {
        return isset($_SESSION['user']['id']);
    }
}
?>