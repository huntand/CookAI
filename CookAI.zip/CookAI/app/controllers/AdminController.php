<?php

namespace App\Controllers;

use Core\Database;
use Core\View;

class AdminController
{
    private Database $db;
    private View $view;

    public function __construct(Database $db)
    {
        $this->db = $db;
        $this->view = new View();
    }

    /**
     * Дэшборд администратора
     */
    public function dashboard()
    {
        $this->requireAdmin();

        // Получить статистику
        $stats = $this->db->queryOne(
            "SELECT 
                (SELECT COUNT(*) FROM users) as total_users,
                (SELECT COUNT(*) FROM recipes) as total_recipes,
                (SELECT COUNT(*) FROM communities) as total_communities,
                (SELECT COUNT(*) FROM challenges) as total_challenges,
                (SELECT COUNT(*) FROM users WHERE created_at >= DATE_SUB(NOW(), INTERVAL 30 DAY)) as new_users_month"
        );

        // График активности пользователей (7 дней)
        $userActivity = $this->db->query(
            "SELECT DATE(created_at) as date, COUNT(*) as count 
             FROM users 
             WHERE created_at >= DATE_SUB(NOW(), INTERVAL 7 DAY)
             GROUP BY DATE(created_at)
             ORDER BY date ASC"
        );

        // Топ рецептов по просмотрам
        $topRecipes = $this->db->query(
            "SELECT r.id, r.title, r.views_count, u.username 
             FROM recipes r 
             JOIN users u ON r.user_id = u.id 
             ORDER BY r.views_count DESC 
             LIMIT 10"
        );

        // Недавние пользователи
        $recentUsers = $this->db->query(
            "SELECT id, username, email, created_at 
             FROM users 
             ORDER BY created_at DESC 
             LIMIT 10"
        );

        $data = [
            'title' => 'Админ-панель',
            'stats' => $stats,
            'user_activity' => $userActivity,
            'top_recipes' => $topRecipes,
            'recent_users' => $recentUsers,
            'user' => $_SESSION['user']
        ];

        return $this->view->render('admin/dashboard', $data);
    }

    /**
     * Управление пользователями
     */
    public function users()
    {
        $this->requireAdmin();

        $page = $_GET['page'] ?? 1;
        $perPage = 20;
        $offset = ($page - 1) * $perPage;

        $search = $_GET['search'] ?? '';
        $searchCondition = $search ? " WHERE username LIKE '%$search%' OR email LIKE '%$search%'" : '';

        // Общее количество
        $count = $this->db->queryOne(
            "SELECT COUNT(*) as count FROM users $searchCondition"
        );
        $totalPages = ceil($count['count'] / $perPage);

        // Получить пользователей
        $users = $this->db->query(
            "SELECT id, username, email, full_name, role, is_active, created_at 
             FROM users 
             $searchCondition
             ORDER BY created_at DESC 
             LIMIT $perPage OFFSET $offset"
        );

        $data = [
            'title' => 'Управление пользователями',
            'users' => $users,
            'search' => htmlspecialchars($search),
            'current_page' => $page,
            'total_pages' => $totalPages,
            'user' => $_SESSION['user']
        ];

        return $this->view->render('admin/users', $data);
    }

    /**
     * Редактировать пользователя
     */
    public function editUser($id)
    {
        $this->requireAdmin();

        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $role = $_POST['role'] ?? 'user';
            $isActive = isset($_POST['is_active']) ? 1 : 0;

            $this->db->execute(
                "UPDATE users SET role = :role, is_active = :is_active WHERE id = :id",
                ['role' => $role, 'is_active' => $isActive, 'id' => (int)$id]
            );

            header('Location: /admin/users?success=1');
            exit;
        }

        $user = $this->db->queryOne(
            "SELECT * FROM users WHERE id = :id",
            ['id' => (int)$id]
        );

        if (!$user) {
            http_response_code(404);
            return "User not found";
        }

        $data = [
            'title' => 'Редактировать пользователя',
            'edit_user' => $user,
            'roles' => ['user', 'moderator', 'admin'],
            'user' => $_SESSION['user']
        ];

        return $this->view->render('admin/edit-user', $data);
    }

    /**
     * Управление сообществами
     */
    public function communities()
    {
        $this->requireAdmin();

        $communities = $this->db->query(
            "SELECT c.*, u.username as admin_name 
             FROM communities c 
             JOIN users u ON c.admin_id = u.id 
             ORDER BY c.created_at DESC 
             LIMIT 50"
        );

        $data = [
            'title' => 'Управление сообществами',
            'communities' => $communities,
            'user' => $_SESSION['user']
        ];

        return $this->view->render('admin/communities', $data);
    }

    /**
     * Модерация сообщества
     */
    public function editCommunity($id)
    {
        $this->requireAdmin();

        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $isActive = isset($_POST['is_active']) ? 1 : 0;

            $this->db->execute(
                "UPDATE communities SET name = :name, description = :description, is_active = :is_active WHERE id = :id",
                [
                    'name' => trim($_POST['name']),
                    'description' => trim($_POST['description']),
                    'is_active' => $isActive,
                    'id' => (int)$id
                ]
            );

            header('Location: /admin/communities?success=1');
            exit;
        }

        $community = $this->db->queryOne(
            "SELECT * FROM communities WHERE id = :id",
            ['id' => (int)$id]
        );

        // Получить членов сообщества
        $members = $this->db->query(
            "SELECT u.id, u.username, u.avatar_url, cm.role, cm.joined_at 
             FROM community_members cm 
             JOIN users u ON cm.user_id = u.id 
             WHERE cm.community_id = :id 
             ORDER BY cm.joined_at DESC",
            ['id' => (int)$id]
        );

        $data = [
            'title' => 'Редактировать сообщество',
            'community' => $community,
            'members' => $members,
            'user' => $_SESSION['user']
        ];

        return $this->view->render('admin/edit-community', $data);
    }

    /**
     * Управление челленджами
     */
    public function challenges()
    {
        $this->requireAdmin();

        $challenges = $this->db->query(
            "SELECT c.*, COUNT(DISTINCT uc.user_id) as participants 
             FROM challenges c 
             LEFT JOIN user_challenges uc ON c.id = uc.challenge_id 
             GROUP BY c.id 
             ORDER BY c.start_date DESC 
             LIMIT 50"
        );

        $data = [
            'title' => 'Управление челленджами',
            'challenges' => $challenges,
            'user' => $_SESSION['user']
        ];

        return $this->view->render('admin/challenges', $data);
    }

    /**
     * Создать новый челледж
     */
    public function createChallenge()
    {
        $this->requireAdmin();

        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $this->db->execute(
                "INSERT INTO challenges (title, description, start_date, end_date, difficulty, reward_points)
                 VALUES (:title, :description, :start_date, :end_date, :difficulty, :reward_points)",
                [
                    'title' => trim($_POST['title']),
                    'description' => trim($_POST['description']),
                    'start_date' => $_POST['start_date'],
                    'end_date' => $_POST['end_date'],
                    'difficulty' => $_POST['difficulty'],
                    'reward_points' => (int)$_POST['reward_points']
                ]
            );

            header('Location: /admin/challenges?success=1');
            exit;
        }

        $data = [
            'title' => 'Создать челленж',
            'difficulties' => ['easy', 'medium', 'hard'],
            'user' => $_SESSION['user']
        ];

        return $this->view->render('admin/create-challenge', $data);
    }

    /**
     * Логи операций
     */
    public function logs()
    {
        $this->requireAdmin();

        // Для простоты используем системные логи PHP
        $logFile = __DIR__ . '/../../storage/logs/app.log';

        $logs = [];
        if (file_exists($logFile)) {
            $logContent = file_get_contents($logFile);
            $logLines = explode("\n", $logContent);
            $logs = array_reverse(array_slice($logLines, -100)); // Последние 100 строк
        }

        $data = [
            'title' => 'Логи системы',
            'logs' => $logs,
            'user' => $_SESSION['user']
        ];

        return $this->view->render('admin/logs', $data);
    }

    /**
     * Модерация рецептов
     */
    public function moderateRecipes()
    {
        $this->requireAdmin();

        $filter = $_GET['filter'] ?? 'all';
        $whereClause = '';

        if ($filter === 'reported') {
            // Получить пожалованные рецепты (можно добавить таблицу reports)
        }

        $recipes = $this->db->query(
            "SELECT r.id, r.title, r.is_published, u.username, r.created_at 
             FROM recipes r 
             JOIN users u ON r.user_id = u.id 
             ORDER BY r.created_at DESC 
             LIMIT 50"
        );

        $data = [
            'title' => 'Модерация рецептов',
            'recipes' => $recipes,
            'filter' => $filter,
            'user' => $_SESSION['user']
        ];

        return $this->view->render('admin/moderate-recipes', $data);
    }

    /**
     * Опубликовать/скрыть рецепт
     */
    public function toggleRecipeStatus($id)
    {
        $this->requireAdmin();

        $recipe = $this->db->queryOne(
            "SELECT is_published FROM recipes WHERE id = :id",
            ['id' => (int)$id]
        );

        if ($recipe) {
            $newStatus = $recipe['is_published'] ? 0 : 1;
            $this->db->execute(
                "UPDATE recipes SET is_published = :status WHERE id = :id",
                ['status' => $newStatus, 'id' => (int)$id]
            );
        }

        header('Location: /admin/moderate-recipes');
        exit;
    }

    /**
     * Проверить права администратора
     */
    private function requireAdmin()
    {
        if (!isset($_SESSION['user']) || $_SESSION['user']['role'] !== 'admin') {
            http_response_code(403);
            die('Access Denied');
        }
    }
}
?>