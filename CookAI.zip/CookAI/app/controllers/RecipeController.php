<?php

namespace App\Controllers;

use Core\Database;
use Core\View;

class RecipeController
{
    private Database $db;
    private View $view;

    public function __construct(Database $db)
    {
        $this->db = $db;
        $this->view = new View();
    }

    /**
     * Просмотр одного рецепта
     */
    public function show($id)
    {
        $id = (int)$id;

        // Получить рецепт с информацией об авторе
        $recipe = $this->db->queryOne(
            "SELECT r.*, u.id as author_id, u.username, u.avatar_url, u.bio 
             FROM recipes r 
             JOIN users u ON r.user_id = u.id 
             WHERE r.id = :id AND r.is_published = TRUE",
            ['id' => $id]
        );

        if (!$recipe) {
            http_response_code(404);
            return "Рецепт не найден";
        }

        // Увеличить счётчик просмотров
        $this->db->execute(
            "UPDATE recipes SET views_count = views_count + 1 WHERE id = :id",
            ['id' => $id]
        );

        // Получить комментарии
        $comments = $this->db->query(
            "SELECT c.*, u.username, u.avatar_url 
             FROM recipe_comments c 
             JOIN users u ON c.user_id = u.id 
             WHERE c.recipe_id = :id 
             ORDER BY c.created_at DESC",
            ['id' => $id]
        );

        // Получить похожие рецепты
        $similarRecipes = $this->db->query(
            "SELECT r.*, u.username 
             FROM recipes r 
             JOIN users u ON r.user_id = u.id 
             WHERE r.diet_type = :diet AND r.id != :id AND r.is_published = TRUE 
             ORDER BY RAND() 
             LIMIT 4",
            ['diet' => $recipe['diet_type'], 'id' => $id]
        );

        // Проверить, в избранном ли рецепт у текущего пользователя
        $isFavorite = false;
        if (isset($_SESSION['user']['id'])) {
            $favorite = $this->db->queryOne(
                "SELECT id FROM favorites WHERE user_id = :user_id AND recipe_id = :recipe_id",
                ['user_id' => $_SESSION['user']['id'], 'recipe_id' => $id]
            );
            $isFavorite = $favorite !== null;
        }

        // Получить рейтинг
        $ratingData = $this->db->queryOne(
            "SELECT COUNT(*) as count, AVG(rating) as avg_rating 
             FROM recipe_comments 
             WHERE recipe_id = :id AND rating IS NOT NULL",
            ['id' => $id]
        );

        // Форматирование данных
        $recipe['ingredients'] = is_string($recipe['ingredients']) 
            ? json_decode($recipe['ingredients'], true) 
            : $recipe['ingredients'];
        $recipe['instructions'] = is_string($recipe['instructions'])
            ? json_decode($recipe['instructions'], true)
            : $recipe['instructions'];

        $data = [
            'title' => $recipe['title'],
            'recipe' => $recipe,
            'comments' => $comments,
            'similar_recipes' => $similarRecipes,
            'is_favorite' => $isFavorite,
            'rating' => [
                'count' => $ratingData['count'] ?? 0,
                'average' => round($ratingData['avg_rating'] ?? 0, 1)
            ],
            'user' => $_SESSION['user'] ?? null
        ];

        return $this->view->render('recipes/show', $data);
    }

    /**
     * Форма создания рецепта (GET)
     */
    public function create()
    {
        if (!$this->isAuthorized()) {
            header('Location: /auth/login');
            exit;
        }

        $data = [
            'title' => 'Создать рецепт',
            'user' => $_SESSION['user'],
            'diets' => ['omnivore', 'vegetarian', 'vegan', 'keto', 'paleo'],
            'difficulties' => ['easy', 'medium', 'hard'],
            'cuisines' => ['Italian', 'Asian', 'Mediterranean', 'American', 'Indian', 'Mexican']
        ];

        return $this->view->render('recipes/create', $data);
    }

    /**
     * Сохранение рецепта (POST)
     */
    public function store()
    {
        if (!$this->isAuthorized() || $_SERVER['REQUEST_METHOD'] !== 'POST') {
            http_response_code(401);
            return json_encode(['error' => 'Unauthorized']);
        }

        // Валидация
        $errors = $this->validateRecipe($_POST);
        if (!empty($errors)) {
            header('Content-Type: application/json');
            return json_encode(['errors' => $errors], JSON_UNESCAPED_UNICODE);
        }

        try {
            // Загрузка изображения
            $imageUrl = $this->uploadImage($_FILES['image'] ?? null);

            // Подготовка данных
            $ingredients = array_filter(
                explode("\n", $_POST['ingredients'] ?? ''),
                fn($item) => trim($item) !== ''
            );
            $instructions = array_filter(
                explode("\n", $_POST['instructions'] ?? ''),
                fn($item) => trim($item) !== ''
            );

            // Вставка в БД
            $sql = "INSERT INTO recipes 
                    (user_id, title, description, image_url, prep_time, cook_time, servings, 
                     difficulty, cuisine, diet_type, calories_per_serving, proteins, fats, carbs, 
                     ingredients, instructions, is_published)
                    VALUES 
                    (:user_id, :title, :description, :image_url, :prep_time, :cook_time, :servings,
                     :difficulty, :cuisine, :diet_type, :calories, :proteins, :fats, :carbs,
                     :ingredients, :instructions, :is_published)";

            $this->db->execute($sql, [
                'user_id' => $_SESSION['user']['id'],
                'title' => trim($_POST['title']),
                'description' => trim($_POST['description']),
                'image_url' => $imageUrl,
                'prep_time' => (int)$_POST['prep_time'],
                'cook_time' => (int)$_POST['cook_time'],
                'servings' => (int)$_POST['servings'],
                'difficulty' => $_POST['difficulty'],
                'cuisine' => $_POST['cuisine'],
                'diet_type' => $_POST['diet_type'],
                'calories' => (float)$_POST['calories'] ?: 0,
                'proteins' => (float)$_POST['proteins'] ?: 0,
                'fats' => (float)$_POST['fats'] ?: 0,
                'carbs' => (float)$_POST['carbs'] ?: 0,
                'ingredients' => json_encode($ingredients),
                'instructions' => json_encode($instructions),
                'is_published' => isset($_POST['is_published']) ? 1 : 0
            ]);

            $recipeId = $this->db->lastInsertId();

            header('Content-Type: application/json');
            return json_encode([
                'success' => true,
                'message' => 'Рецепт успешно создан!',
                'recipe_id' => $recipeId,
                'redirect' => "/recipe/$recipeId"
            ]);
        } catch (\Exception $e) {
            header('Content-Type: application/json');
            return json_encode(['error' => 'Ошибка при сохранении рецепта'], JSON_UNESCAPED_UNICODE);
        }
    }

    /**
     * Редактирование рецепта (GET)
     */
    public function edit($id)
    {
        if (!$this->isAuthorized()) {
            header('Location: /auth/login');
            exit;
        }

        $id = (int)$id;
        $recipe = $this->db->queryOne(
            "SELECT * FROM recipes WHERE id = :id AND user_id = :user_id",
            ['id' => $id, 'user_id' => $_SESSION['user']['id']]
        );

        if (!$recipe) {
            http_response_code(403);
            return "Доступ запрещён";
        }

        // Декодировать JSON
        $recipe['ingredients'] = is_string($recipe['ingredients']) 
            ? json_decode($recipe['ingredients'], true) 
            : $recipe['ingredients'];
        $recipe['instructions'] = is_string($recipe['instructions'])
            ? json_decode($recipe['instructions'], true)
            : $recipe['instructions'];

        $data = [
            'title' => 'Редактировать рецепт',
            'recipe' => $recipe,
            'user' => $_SESSION['user'],
            'diets' => ['omnivore', 'vegetarian', 'vegan', 'keto', 'paleo'],
            'difficulties' => ['easy', 'medium', 'hard'],
            'cuisines' => ['Italian', 'Asian', 'Mediterranean', 'American', 'Indian', 'Mexican']
        ];

        return $this->view->render('recipes/edit', $data);
    }

    /**
     * Обновление рецепта (POST)
     */
    public function update($id)
    {
        if (!$this->isAuthorized() || $_SERVER['REQUEST_METHOD'] !== 'POST') {
            http_response_code(401);
            return json_encode(['error' => 'Unauthorized']);
        }

        $id = (int)$id;

        // Проверить владельца
        $recipe = $this->db->queryOne(
            "SELECT user_id FROM recipes WHERE id = :id",
            ['id' => $id]
        );

        if (!$recipe || $recipe['user_id'] != $_SESSION['user']['id']) {
            http_response_code(403);
            return json_encode(['error' => 'Forbidden']);
        }

        try {
            $imageUrl = null;
            if (!empty($_FILES['image']['name'])) {
                $imageUrl = $this->uploadImage($_FILES['image']);
            }

            $ingredients = array_filter(
                explode("\n", $_POST['ingredients'] ?? ''),
                fn($item) => trim($item) !== ''
            );
            $instructions = array_filter(
                explode("\n", $_POST['instructions'] ?? ''),
                fn($item) => trim($item) !== ''
            );

            $sql = "UPDATE recipes SET 
                    title = :title,
                    description = :description,
                    prep_time = :prep_time,
                    cook_time = :cook_time,
                    servings = :servings,
                    difficulty = :difficulty,
                    cuisine = :cuisine,
                    diet_type = :diet_type,
                    calories_per_serving = :calories,
                    proteins = :proteins,
                    fats = :fats,
                    carbs = :carbs,
                    ingredients = :ingredients,
                    instructions = :instructions,
                    is_published = :is_published";

            $params = [
                'title' => trim($_POST['title']),
                'description' => trim($_POST['description']),
                'prep_time' => (int)$_POST['prep_time'],
                'cook_time' => (int)$_POST['cook_time'],
                'servings' => (int)$_POST['servings'],
                'difficulty' => $_POST['difficulty'],
                'cuisine' => $_POST['cuisine'],
                'diet_type' => $_POST['diet_type'],
                'calories' => (float)$_POST['calories'] ?: 0,
                'proteins' => (float)$_POST['proteins'] ?: 0,
                'fats' => (float)$_POST['fats'] ?: 0,
                'carbs' => (float)$_POST['carbs'] ?: 0,
                'ingredients' => json_encode($ingredients),
                'instructions' => json_encode($instructions),
                'is_published' => isset($_POST['is_published']) ? 1 : 0
            ];

            if ($imageUrl) {
                $sql .= ", image_url = :image_url";
                $params['image_url'] = $imageUrl;
            }

            $sql .= " WHERE id = :id";
            $params['id'] = $id;

            $this->db->execute($sql, $params);

            header('Content-Type: application/json');
            return json_encode([
                'success' => true,
                'message' => 'Рецепт обновлён!',
                'redirect' => "/recipe/$id"
            ]);
        } catch (\Exception $e) {
            header('Content-Type: application/json');
            return json_encode(['error' => $e->getMessage()]);
        }
    }

    /**
     * Удаление рецепта
     */
    public function delete($id)
    {
        if (!$this->isAuthorized() || $_SERVER['REQUEST_METHOD'] !== 'POST') {
            http_response_code(401);
            return json_encode(['error' => 'Unauthorized']);
        }

        $id = (int)$id;

        // Проверить владельца
        $recipe = $this->db->queryOne(
            "SELECT user_id FROM recipes WHERE id = :id",
            ['id' => $id]
        );

        if (!$recipe || $recipe['user_id'] != $_SESSION['user']['id']) {
            http_response_code(403);
            return json_encode(['error' => 'Forbidden']);
        }

        try {
            $this->db->execute("DELETE FROM recipes WHERE id = :id", ['id' => $id]);

            header('Content-Type: application/json');
            return json_encode([
                'success' => true,
                'message' => 'Рецепт удалён',
                'redirect' => '/recipes'
            ]);
        } catch (\Exception $e) {
            header('Content-Type: application/json');
            return json_encode(['error' => 'Ошибка при удалении']);
        }
    }

    /**
     * Добавить в избранное
     */
    public function addToFavorite($id)
    {
        if (!$this->isAuthorized()) {
            http_response_code(401);
            return json_encode(['error' => 'Unauthorized']);
        }

        $id = (int)$id;

        try {
            $this->db->execute(
                "INSERT IGNORE INTO favorites (user_id, recipe_id) VALUES (:user_id, :recipe_id)",
                ['user_id' => $_SESSION['user']['id'], 'recipe_id' => $id]
            );

            header('Content-Type: application/json');
            return json_encode(['success' => true, 'message' => 'Добавлено в избранное']);
        } catch (\Exception $e) {
            header('Content-Type: application/json');
            return json_encode(['error' => 'Ошибка']);
        }
    }

    /**
     * Удалить из избранного
     */
    public function removeFromFavorite($id)
    {
        if (!$this->isAuthorized()) {
            http_response_code(401);
            return json_encode(['error' => 'Unauthorized']);
        }

        $id = (int)$id;

        try {
            $this->db->execute(
                "DELETE FROM favorites WHERE user_id = :user_id AND recipe_id = :recipe_id",
                ['user_id' => $_SESSION['user']['id'], 'recipe_id' => $id]
            );

            header('Content-Type: application/json');
            return json_encode(['success' => true, 'message' => 'Удалено из избранного']);
        } catch (\Exception $e) {
            header('Content-Type: application/json');
            return json_encode(['error' => 'Ошибка']);
        }
    }

    /**
     * Добавить комментарий
     */
    public function addComment($id)
    {
        if (!$this->isAuthorized() || $_SERVER['REQUEST_METHOD'] !== 'POST') {
            http_response_code(401);
            return json_encode(['error' => 'Unauthorized']);
        }

        $id = (int)$id;
        $text = trim($_POST['comment'] ?? '');
        $rating = (int)$_POST['rating'] ?? null;

        if (strlen($text) < 2) {
            return json_encode(['error' => 'Комментарий слишком короткий']);
        }

        try {
            $this->db->execute(
                "INSERT INTO recipe_comments (recipe_id, user_id, comment_text, rating) 
                 VALUES (:recipe_id, :user_id, :text, :rating)",
                [
                    'recipe_id' => $id,
                    'user_id' => $_SESSION['user']['id'],
                    'text' => $text,
                    'rating' => $rating
                ]
            );

            header('Content-Type: application/json');
            return json_encode(['success' => true, 'message' => 'Комментарий добавлен']);
        } catch (\Exception $e) {
            header('Content-Type: application/json');
            return json_encode(['error' => 'Ошибка при добавлении комментария']);
        }
    }

    /**
     * Валидация рецепта
     */
    private function validateRecipe($data)
    {
        $errors = [];

        if (strlen(trim($data['title'] ?? '')) < 3) {
            $errors['title'] = 'Название должно быть минимум 3 символа';
        }

        if (strlen(trim($data['description'] ?? '')) < 10) {
            $errors['description'] = 'Описание должно быть минимум 10 символов';
        }

        if (!isset($data['prep_time']) || (int)$data['prep_time'] < 0) {
            $errors['prep_time'] = 'Укажите корректное время подготовки';
        }

        if (!isset($data['cook_time']) || (int)$data['cook_time'] < 0) {
            $errors['cook_time'] = 'Укажите корректное время приготовления';
        }

        if (strlen(trim($data['ingredients'] ?? '')) < 10) {
            $errors['ingredients'] = 'Укажите минимум один ингредиент';
        }

        if (strlen(trim($data['instructions'] ?? '')) < 10) {
            $errors['instructions'] = 'Укажите инструкции приготовления';
        }

        return $errors;
    }

    /**
     * Загрузка изображения
     */
    private function uploadImage($file)
    {
        if (!$file || $file['error'] !== UPLOAD_ERR_OK) {
            return null;
        }

        $allowedMimes = ['image/jpeg', 'image/png', 'image/webp'];
        $allowedExtensions = ['jpg', 'jpeg', 'png', 'webp'];

        if (!in_array($file['type'], $allowedMimes)) {
            throw new \Exception('Недопустимый формат изображения');
        }

        $filename = uniqid('recipe_') . '.' . pathinfo($file['name'], PATHINFO_EXTENSION);
        $uploadDir = __DIR__ . '/../../storage/uploads/recipes/';

        if (!is_dir($uploadDir)) {
            mkdir($uploadDir, 0755, true);
        }

        if (!move_uploaded_file($file['tmp_name'], $uploadDir . $filename)) {
            throw new \Exception('Ошибка при загрузке файла');
        }

        return '/storage/uploads/recipes/' . $filename;
    }

    /**
     * Проверить авторизацию
     */
    private function isAuthorized()
    {
        return isset($_SESSION['user']['id']);
    }
}
?>