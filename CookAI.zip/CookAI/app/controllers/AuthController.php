<?php

namespace App\Controllers;

use App\Models\User;
use App\Middleware\AuthMiddleware;
use Core\Database;

class AuthController
{
    private Database $db;
    private User $userModel;

    public function __construct(Database $db)
    {
        $this->db = $db;
        $this->userModel = new User($db);
    }

    /**
     * Вход
     */
    public function login()
    {
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            http_response_code(405);
            return json_encode(['error' => 'Method Not Allowed']);
        }

        $input = $this->getInput();

        // Валидация
        if (empty($input['username']) || empty($input['password'])) {
            http_response_code(400);
            return json_encode(['error' => 'Username and password required']);
        }

        // Найти пользователя
        $user = $this->userModel->findByUsername($input['username']);
        
        if (!$user) {
            // Проверить email
            $user = $this->userModel->findByEmail($input['username']);
        }

        if (!$user) {
            http_response_code(401);
            return json_encode(['error' => 'Invalid credentials']);
        }

        // Проверить пароль
        if (!password_verify($input['password'], $user['password_hash'])) {
            http_response_code(401);
            return json_encode(['error' => 'Invalid credentials']);
        }

        // Проверить активность
        if (!$user['is_active']) {
            http_response_code(403);
            return json_encode(['error' => 'Account is inactive']);
        }

        // Установить сессию
        $_SESSION['user'] = [
            'id' => $user['id'],
            'username' => $user['username'],
            'email' => $user['email'],
            'role' => $user['role'] ?? 'user',
            'avatar_url' => $user['avatar_url']
        ];

        // Создать JWT токен
        $token = AuthMiddleware::generateToken($user['id'], $user['username'], $user['role'] ?? 'user');

        // Логирование
        $this->logAction($user['id'], 'login', 'success');

        header('Content-Type: application/json');
        return json_encode([
            'success' => true,
            'message' => 'Вход успешен',
            'user' => $_SESSION['user'],
            'token' => $token
        ]);
    }

    /**
     * Регистрация
     */
    public function register()
    {
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            http_response_code(405);
            return json_encode(['error' => 'Method Not Allowed']);
        }

        $input = $this->getInput();

        // Валидация
        $errors = $this->validateRegistration($input);
        if (!empty($errors)) {
            http_response_code(400);
            return json_encode(['errors' => $errors]);
        }

        // Проверить, существует ли пользователь
        if ($this->userModel->findByUsername($input['username'])) {
            http_response_code(409);
            return json_encode(['error' => 'Username already exists']);
        }

        if ($this->userModel->findByEmail($input['email'])) {
            http_response_code(409);
            return json_encode(['error' => 'Email already exists']);
        }

        try {
            // Создать пользователя
            $userId = $this->userModel->create([
                'username' => $input['username'],
                'email' => $input['email'],
                'password' => $input['password'],
                'full_name' => $input['full_name'] ?? '',
                'diet_preference' => $input['diet_preference'] ?? 'omnivore'
            ]);

            // Логирование
            $this->logAction($userId, 'register', 'success');

            header('Content-Type: application/json');
            return json_encode([
                'success' => true,
                'message' => 'Регистрация успешна',
                'user_id' => $userId
            ]);
        } catch (\Exception $e) {
            http_response_code(500);
            return json_encode(['error' => 'Registration failed']);
        }
    }

    /**
     * Выход
     */
    public function logout()
    {
        if (isset($_SESSION['user'])) {
            $this->logAction($_SESSION['user']['id'], 'logout', 'success');
            session_destroy();
        }

        header('Content-Type: application/json');
        return json_encode(['success' => true, 'message' => 'Выход выполнен']);
    }

    /**
     * Забыли пароль
     */
    public function forgotPassword()
    {
        $input = $this->getInput();

        if (empty($input['email'])) {
            http_response_code(400);
            return json_encode(['error' => 'Email required']);
        }

        $user = $this->userModel->findByEmail($input['email']);

        if ($user) {
            // Генерировать токен для восстановления
            $token = bin2hex(random_bytes(32));
            
            // Сохранить токен в БД с временем жизни
            $this->db->execute(
                "INSERT INTO password_resets (user_id, token, expires_at) 
                 VALUES (:user_id, :token, DATE_ADD(NOW(), INTERVAL 1 HOUR))",
                ['user_id' => $user['id'], 'token' => $token]
            );

            // Отправить email (TODO: реальная отправка)
            $resetUrl = "https://cookaiapp.ru/auth/reset-password?token=$token";
            // mail($user['email'], 'Reset Password', "Click: $resetUrl");
        }

        header('Content-Type: application/json');
        return json_encode([
            'success' => true,
            'message' => 'Проверьте вашу почту для восстановления пароля'
        ]);
    }

    /**
     * Сбросить пароль
     */
    public function resetPassword()
    {
        $input = $this->getInput();

        if (empty($input['token']) || empty($input['password'])) {
            http_response_code(400);
            return json_encode(['error' => 'Token and password required']);
        }

        // Проверить токен
        $reset = $this->db->queryOne(
            "SELECT * FROM password_resets 
             WHERE token = :token AND expires_at > NOW()",
            ['token' => $input['token']]
        );

        if (!$reset) {
            http_response_code(400);
            return json_encode(['error' => 'Invalid or expired token']);
        }

        try {
            // Обновить пароль
            $this->userModel->changePassword($reset['user_id'], '', $input['password']);

            // Удалить использованный токен
            $this->db->execute(
                "DELETE FROM password_resets WHERE id = :id",
                ['id' => $reset['id']]
            );

            $this->logAction($reset['user_id'], 'password_reset', 'success');

            header('Content-Type: application/json');
            return json_encode([
                'success' => true,
                'message' => 'Пароль успешно восстановлен'
            ]);
        } catch (\Exception $e) {
            http_response_code(500);
            return json_encode(['error' => 'Password reset failed']);
        }
    }

    /**
     * Обновить токен
     */
    public function refreshToken()
    {
        if (!isset($_SESSION['user'])) {
            http_response_code(401);
            return json_encode(['error' => 'Unauthorized']);
        }

        $user = $_SESSION['user'];
        $token = AuthMiddleware::generateToken($user['id'], $user['username'], $user['role']);

        header('Content-Type: application/json');
        return json_encode([
            'success' => true,
            'token' => $token
        ]);
    }

    /**
     * Валидация регистрации
     */
    private function validateRegistration($data): array
    {
        $errors = [];

        if (strlen($data['username'] ?? '') < 3) {
            $errors['username'] = 'Username must be at least 3 characters';
        }

        if (!filter_var($data['email'] ?? '', FILTER_VALIDATE_EMAIL)) {
            $errors['email'] = 'Invalid email format';
        }

        if (strlen($data['password'] ?? '') < 8) {
            $errors['password'] = 'Password must be at least 8 characters';
        }

        if (($data['password'] ?? '') !== ($data['password_confirm'] ?? '')) {
            $errors['password_confirm'] = 'Passwords do not match';
        }

        return $errors;
    }

    /**
     * Получить входные данные
     */
    private function getInput(): array
    {
        $input = [];
        
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $contentType = $_SERVER['CONTENT_TYPE'] ?? '';
            
            if (strpos($contentType, 'application/json') !== false) {
                $input = json_decode(file_get_contents('php://input'), true) ?? [];
            } else {
                $input = $_POST;
            }
        }

        return $input;
    }

    /**
     * Логирование действия
     */
    private function logAction($userId, $action, $status)
    {
        try {
            $this->db->execute(
                "INSERT INTO logs (user_id, action, status, ip_address) 
                 VALUES (:user_id, :action, :status, :ip)",
                [
                    'user_id' => $userId,
                    'action' => $action,
                    'status' => $status,
                    'ip' => $_SERVER['REMOTE_ADDR']
                ]
            );
        } catch (\Exception $e) {
            // Игнорировать ошибки логирования
        }
    }
}
?>