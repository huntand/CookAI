<?php

namespace App\Controllers;

use Core\Database;
use Core\View;

class HomeController
{
    private Database $db;
    private View $view;

    public function __construct(Database $db)
    {
        $this->db = $db;
        $this->view = new View();
    }

    /**
     * Главная страница с популярными рецептами
     */
    public function index()
    {
        // Получить популярные рецепты (по просмотрам)
        $popularRecipes = $this->db->query(
            "SELECT r.*, u.username, u.avatar_url 
             FROM recipes r 
             JOIN users u ON r.user_id = u.id 
             WHERE r.is_published = TRUE 
             ORDER BY r.views_count DESC 
             LIMIT 8"
        );

        // Получить сезонные рецепты (последние добавленные)
        $seasonalRecipes = $this->db->query(
            "SELECT r.*, u.username, u.avatar_url 
             FROM recipes r 
             JOIN users u ON r.user_id = u.id 
             WHERE r.is_published = TRUE 
             ORDER BY r.created_at DESC 
             LIMIT 8"
        );

        // Получить рецепты по диетам
        $veganRecipes = $this->db->query(
            "SELECT r.*, u.username 
             FROM recipes r 
             JOIN users u ON r.user_id = u.id 
             WHERE r.diet_type = 'vegan' AND r.is_published = TRUE 
             LIMIT 4"
        );

        // Получить активные челленджи
        $activeChallenges = $this->db->query(
            "SELECT * FROM challenges 
             WHERE start_date <= CURDATE() AND end_date >= CURDATE() 
             LIMIT 3"
        );

        // Получить статистику
        $stats = $this->db->queryOne(
            "SELECT 
                (SELECT COUNT(*) FROM recipes WHERE is_published = TRUE) as total_recipes,
                (SELECT COUNT(*) FROM users) as total_users,
                (SELECT COUNT(*) FROM communities) as total_communities"
        );

        // Подготовка данных для шаблона
        $data = [
            'title' => 'CookAI - Интеллектуальная кулинарная платформа',
            'popular_recipes' => $popularRecipes,
            'seasonal_recipes' => $seasonalRecipes,
            'vegan_recipes' => $veganRecipes,
            'active_challenges' => $activeChallenges,
            'stats' => $stats,
            'user' => $_SESSION['user'] ?? null
        ];

        return $this->view->render('home/index', $data);
    }

    /**
     * Страница со всеми рецептами с пагинацией
     */
    public function allRecipes()
    {
        $page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
        $perPage = 12;
        $offset = ($page - 1) * $perPage;

        // Фильтры
        $filters = $this->getFilters();
        $whereClause = $this->buildWhereClause($filters);

        // Общее количество рецептов
        $countResult = $this->db->queryOne(
            "SELECT COUNT(*) as count FROM recipes WHERE is_published = TRUE $whereClause"
        );
        $totalRecipes = $countResult['count'] ?? 0;
        $totalPages = ceil($totalRecipes / $perPage);

        // Получить рецепты для текущей страницы
        $recipes = $this->db->query(
            "SELECT r.*, u.username, u.avatar_url,
                    (SELECT COUNT(*) FROM favorites WHERE recipe_id = r.id) as favorites_count
             FROM recipes r 
             JOIN users u ON r.user_id = u.id 
             WHERE r.is_published = TRUE $whereClause
             ORDER BY r.created_at DESC 
             LIMIT $perPage OFFSET $offset"
        );

        $recipes = $this->formatRecipes($recipes);

        $data = [
            'title' => 'Все рецепты',
            'recipes' => $recipes,
            'current_page' => $page,
            'total_pages' => $totalPages,
            'total_recipes' => $totalRecipes,
            'filters' => $filters,
            'user' => $_SESSION['user'] ?? null
        ];

        return $this->view->render('home/all-recipes', $data);
    }

    /**
     * Поиск рецептов
     */
    public function search()
    {
        $query = $_GET['q'] ?? '';
        $results = [];

        if (strlen($query) >= 2) {
            // Поиск по названию и описанию
            $results = $this->db->query(
                "SELECT r.*, u.username, u.avatar_url 
                 FROM recipes r 
                 JOIN users u ON r.user_id = u.id 
                 WHERE r.is_published = TRUE AND 
                       (r.title LIKE :query OR r.description LIKE :query)
                 LIMIT 20",
                ['query' => '%' . $query . '%']
            );
        }

        $results = $this->formatRecipes($results);

        $data = [
            'title' => 'Результаты поиска',
            'query' => htmlspecialchars($query),
            'results' => $results,
            'user' => $_SESSION['user'] ?? null
        ];

        return $this->view->render('home/search-results', $data);
    }

    /**
     * Страница рецепта по диетам
     */
    public function byDiet()
    {
        $diet = $_GET['type'] ?? 'omnivore';
        $validDiets = ['omnivore', 'vegetarian', 'vegan', 'keto', 'paleo'];

        if (!in_array($diet, $validDiets)) {
            http_response_code(400);
            return "Invalid diet type";
        }

        $recipes = $this->db->query(
            "SELECT r.*, u.username, u.avatar_url 
             FROM recipes r 
             JOIN users u ON r.user_id = u.id 
             WHERE r.diet_type = :diet AND r.is_published = TRUE 
             ORDER BY r.created_at DESC 
             LIMIT 20",
            ['diet' => $diet]
        );

        $recipes = $this->formatRecipes($recipes);

        $data = [
            'title' => 'Рецепты: ' . $this->getDietLabel($diet),
            'diet_type' => $diet,
            'recipes' => $recipes,
            'user' => $_SESSION['user'] ?? null
        ];

        return $this->view->render('home/diet-recipes', $data);
    }

    /**
     * Получить фильтры из GET параметров
     */
    private function getFilters()
    {
        return [
            'diet' => $_GET['diet'] ?? null,
            'difficulty' => $_GET['difficulty'] ?? null,
            'cuisine' => $_GET['cuisine'] ?? null,
            'time_max' => $_GET['time_max'] ?? null,
            'calories_max' => $_GET['calories_max'] ?? null,
        ];
    }

    /**
     * Построить WHERE клаузулу на основе фильтров
     */
    private function buildWhereClause($filters)
    {
        $conditions = [];

        if ($filters['diet'] && in_array($filters['diet'], ['omnivore', 'vegetarian', 'vegan', 'keto', 'paleo'])) {
            $conditions[] = "r.diet_type = '" . addslashes($filters['diet']) . "'";
        }

        if ($filters['difficulty'] && in_array($filters['difficulty'], ['easy', 'medium', 'hard'])) {
            $conditions[] = "r.difficulty = '" . addslashes($filters['difficulty']) . "'";
        }

        if ($filters['cuisine']) {
            $conditions[] = "r.cuisine LIKE '%" . addslashes($filters['cuisine']) . "%'";
        }

        if ($filters['time_max'] && is_numeric($filters['time_max'])) {
            $time = (int)$filters['time_max'];
            $conditions[] = "(r.prep_time + r.cook_time) <= $time";
        }

        if ($filters['calories_max'] && is_numeric($filters['calories_max'])) {
            $calories = (int)$filters['calories_max'];
            $conditions[] = "r.calories_per_serving <= $calories";
        }

        return count($conditions) > 0 ? 'AND ' . implode(' AND ', $conditions) : '';
    }

    /**
     * Форматировать рецепты для отображения
     */
    private function formatRecipes($recipes)
    {
        return array_map(function ($recipe) {
            $recipe['prep_cook_time'] = ($recipe['prep_time'] ?? 0) + ($recipe['cook_time'] ?? 0);
            $recipe['ingredients'] = is_string($recipe['ingredients'] ?? null) 
                ? json_decode($recipe['ingredients'], true) 
                : $recipe['ingredients'];
            $recipe['instructions'] = is_string($recipe['instructions'] ?? null)
                ? json_decode($recipe['instructions'], true)
                : $recipe['instructions'];
            return $recipe;
        }, $recipes);
    }

    /**
     * Получить название диеты
     */
    private function getDietLabel($diet)
    {
        $labels = [
            'omnivore' => 'Обычное питание',
            'vegetarian' => 'Вегетарианское',
            'vegan' => 'Веганское',
            'keto' => 'Кето-диета',
            'paleo' => 'Палео-диета'
        ];
        return $labels[$diet] ?? $diet;
    }
}
?>