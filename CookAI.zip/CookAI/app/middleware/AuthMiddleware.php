<?php

namespace App\Middleware;

use Core\Database;

class AuthMiddleware
{
    private Database $db;
    private string $jwtSecret;

    public function __construct(Database $db)
    {
        $this->db = $db;
        $this->jwtSecret = $_ENV['JWT_SECRET'] ?? 'your-secret-key';
    }

    /**
     * Проверить аутентификацию
     */
    public function handle()
    {
        // Проверить сессию
        if (isset($_SESSION['user'])) {
            return true;
        }

        // Проверить JWT токен
        $token = $this->getBearerToken();
        if ($token && $this->verifyToken($token)) {
            return true;
        }

        return false;
    }

    /**
     * Получить токен из заголовка Authorization
     */
    private function getBearerToken(): ?string
    {
        $headers = getallheaders();
        if (isset($headers['Authorization'])) {
            if (preg_match('/Bearer\s+(.+)/', $headers['Authorization'], $matches)) {
                return $matches[1];
            }
        }
        return null;
    }

    /**
     * Проверить JWT токен
     */
    private function verifyToken(string $token): bool
    {
        try {
            $parts = explode('.', $token);
            if (count($parts) !== 3) {
                return false;
            }

            list($header, $payload, $signature) = $parts;

            // Проверить подпись
            $data = $header . '.' . $payload;
            $calculatedSignature = hash_hmac('sha256', $data, $this->jwtSecret, true);
            $calculatedSignature = rtrim(strtr(base64_encode($calculatedSignature), '+/', '-_'), '=');

            if ($signature !== $calculatedSignature) {
                return false;
            }

            // Декодировать payload
            $decoded = json_decode(base64_decode(strtr($payload, '-_', '+/')), true);

            // Проверить срок действия
            if (isset($decoded['exp']) && $decoded['exp'] < time()) {
                return false;
            }

            // Сохранить пользователя в сессию
            $_SESSION['user'] = [
                'id' => $decoded['sub'],
                'username' => $decoded['username'],
                'role' => $decoded['role']
            ];

            return true;
        } catch (\Exception $e) {
            return false;
        }
    }

    /**
     * Генерировать JWT токен
     */
    public static function generateToken($userId, $username, $role, $expiresIn = 86400): string
    {
        $secret = $_ENV['JWT_SECRET'] ?? 'your-secret-key';
        
        $header = json_encode(['typ' => 'JWT', 'alg' => 'HS256']);
        $payload = json_encode([
            'sub' => $userId,
            'username' => $username,
            'role' => $role,
            'iat' => time(),
            'exp' => time() + $expiresIn
        ]);

        $header = rtrim(strtr(base64_encode($header), '+/', '-_'), '=');
        $payload = rtrim(strtr(base64_encode($payload), '+/', '-_'), '=');

        $signature = hash_hmac('sha256', "$header.$payload", $secret, true);
        $signature = rtrim(strtr(base64_encode($signature), '+/', '-_'), '=');

        return "$header.$payload.$signature";
    }
}
?>