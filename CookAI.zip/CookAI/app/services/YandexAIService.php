Основные методы:
- generateText() — генерация текста через Yandex GPT
- analyzeFood() — анализ фото блюда (Computer Vision)
- generateImage() — генерация изображений
- generateRecipe() — создание рецепта по ингредиентам
- generateMealPlan() — план питания на неделю
- askCookingAdvice() — советник по готовке
- generateRecipeDescription() — описание рецепта
- generateCookingTips() — советы по приготовлению
- suggestIngredientReplacement() — замена ингредиента