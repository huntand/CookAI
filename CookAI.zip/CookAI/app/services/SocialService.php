<?php

namespace App\Services;

use Core\Database;

class SocialService
{
    private Database $db;

    public function __construct(Database $db)
    {
        $this->db = $db;
    }

    // ===== ДРУЗЬЯ =====

    /**
     * Добавить в друзья
     */
    public function addFriend(int $userId, int $friendId): bool
    {
        if ($userId == $friendId) {
            return false;
        }

        $exists = $this->db->queryOne(
            "SELECT id FROM friends WHERE user_id = :user_id AND friend_id = :friend_id",
            ['user_id' => $userId, 'friend_id' => $friendId]
        );

        if ($exists) {
            return false;
        }

        return $this->db->execute(
            "INSERT INTO friends (user_id, friend_id, status) VALUES (:user_id, :friend_id, 'pending')",
            ['user_id' => $userId, 'friend_id' => $friendId]
        );
    }

    /**
     * Принять запрос в друзья
     */
    public function acceptFriend(int $userId, int $friendId): bool
    {
        $this->db->execute(
            "UPDATE friends SET status = 'accepted' 
             WHERE user_id = :friend_id AND friend_id = :user_id",
            ['user_id' => $userId, 'friend_id' => $friendId]
        );

        return $this->db->execute(
            "INSERT IGNORE INTO friends (user_id, friend_id, status) 
             VALUES (:user_id, :friend_id, 'accepted')",
            ['user_id' => $userId, 'friend_id' => $friendId]
        );
    }

    /**
     * Отклонить запрос в друзья
     */
    public function rejectFriend(int $userId, int $friendId): bool
    {
        return $this->db->execute(
            "DELETE FROM friends WHERE 
             (user_id = :user_id AND friend_id = :friend_id AND status = 'pending') OR
             (user_id = :friend_id AND friend_id = :user_id AND status = 'pending')",
            ['user_id' => $userId, 'friend_id' => $friendId]
        );
    }

    /**
     * Удалить из друзей
     */
    public function removeFriend(int $userId, int $friendId): bool
    {
        return $this->db->execute(
            "DELETE FROM friends WHERE 
             (user_id = :user_id AND friend_id = :friend_id) OR
             (user_id = :friend_id AND friend_id = :user_id)",
            ['user_id' => $userId, 'friend_id' => $friendId]
        );
    }

    /**
     * Получить друзей пользователя
     */
    public function getFriends(int $userId): array
    {
        return $this->db->query(
            "SELECT u.id, u.username, u.avatar_url, u.bio, f.status
             FROM friends f
             JOIN users u ON (
                 (f.user_id = :user_id AND u.id = f.friend_id) OR
                 (f.friend_id = :user_id AND u.id = f.user_id)
             )
             WHERE f.status = 'accepted'
             ORDER BY u.username ASC",
            ['user_id' => $userId]
        );
    }

    /**
     * Получить входящие запросы в друзья
     */
    public function getFriendRequests(int $userId): array
    {
        return $this->db->query(
            "SELECT u.id, u.username, u.avatar_url, u.bio
             FROM friends f
             JOIN users u ON f.user_id = u.id
             WHERE f.friend_id = :user_id AND f.status = 'pending'
             ORDER BY f.created_at DESC",
            ['user_id' => $userId]
        );
    }

    /**
     * Получить количество друзей
     */
    public function getFriendsCount(int $userId): int
    {
        $result = $this->db->queryOne(
            "SELECT COUNT(*) as count FROM friends 
             WHERE status = 'accepted' AND 
             (user_id = :user_id OR friend_id = :user_id)",
            ['user_id' => $userId]
        );
        return $result['count'] ?? 0;
    }

    /**
     * Проверить, являются ли пользователи друзьями
     */
    public function areFriends(int $userId1, int $userId2): bool
    {
        $result = $this->db->queryOne(
            "SELECT id FROM friends 
             WHERE status = 'accepted' AND 
             ((user_id = :user1 AND friend_id = :user2) OR 
              (user_id = :user2 AND friend_id = :user1))",
            ['user1' => $userId1, 'user2' => $userId2]
        );

        return $result !== null;
    }

    /**
     * Проверить, отправлен ли запрос в друзья
     */
    public function hasPendingRequest(int $fromId, int $toId): bool
    {
        $result = $this->db->queryOne(
            "SELECT id FROM friends 
             WHERE user_id = :from_id AND friend_id = :to_id AND status = 'pending'",
            ['from_id' => $fromId, 'to_id' => $toId]
        );

        return $result !== null;
    }

    // ===== СООБЩЕНИЯ =====

    /**
     * Отправить сообщение
     */
    public function sendMessage(int $fromId, int $toId, string $text): int
    {
        $this->db->execute(
            "INSERT INTO messages (from_id, to_id, message_text) 
             VALUES (:from_id, :to_id, :text)",
            ['from_id' => $fromId, 'to_id' => $toId, 'text' => $text]
        );

        return (int)$this->db->lastInsertId();
    }

    /**
     * Получить непрочитанные сообщения
     */
    public function getUnreadMessages(int $userId): int
    {
        $result = $this->db->queryOne(
            "SELECT COUNT(*) as count FROM messages 
             WHERE to_id = :user_id AND is_read = FALSE",
            ['user_id' => $userId]
        );

        return $result['count'] ?? 0;
    }

    /**
     * Получить контакты для чата
     */
    public function getChatContacts(int $userId): array
    {
        return $this->db->query(
            "SELECT DISTINCT 
                CASE 
                    WHEN from_id = :user_id THEN to_id 
                    ELSE from_id 
                END as contact_id,
                u.username, u.avatar_url,
                (SELECT message_text FROM messages m 
                 WHERE (m.from_id = contact_id OR m.to_id = contact_id) 
                 ORDER BY m.created_at DESC LIMIT 1) as last_message,
                (SELECT COUNT(*) FROM messages m2 
                 WHERE m2.to_id = :user_id AND m2.is_read = FALSE AND 
                 (m2.from_id = contact_id OR m2.to_id = contact_id)) as unread_count
             FROM messages m
             JOIN users u ON u.id = CASE 
                                        WHEN from_id = :user_id THEN to_id 
                                        ELSE from_id 
                                    END
             WHERE from_id = :user_id OR to_id = :user_id
             GROUP BY contact_id
             ORDER BY (SELECT created_at FROM messages WHERE 
                      (from_id = contact_id AND to_id = :user_id) OR
                      (from_id = :user_id AND to_id = contact_id)
                      ORDER BY created_at DESC LIMIT 1) DESC",
            ['user_id' => $userId]
        );
    }

    // ===== КОММЕНТАРИИ И РЕЙТИНГ =====

    /**
     * Получить комментарии к рецепту
     */
    public function getRecipeComments(int $recipeId, int $limit = 50): array
    {
        return $this->db->query(
            "SELECT c.*, u.username, u.avatar_url
             FROM recipe_comments c
             JOIN users u ON c.user_id = u.id
             WHERE c.recipe_id = :recipe_id
             ORDER BY c.created_at DESC
             LIMIT :limit",
            ['recipe_id' => $recipeId, 'limit' => $limit]
        );
    }

    /**
     * Добавить комментарий
     */
    public function addComment(int $recipeId, int $userId, string $text, int $rating = null): bool
    {
        return $this->db->execute(
            "INSERT INTO recipe_comments (recipe_id, user_id, comment_text, rating) 
             VALUES (:recipe_id, :user_id, :text, :rating)",
            [
                'recipe_id' => $recipeId,
                'user_id' => $userId,
                'text' => $text,
                'rating' => $rating
            ]
        );
    }

    /**
     * Получить средний рейтинг рецепта
     */
    public function getRecipeRating(int $recipeId): array
    {
        $result = $this->db->queryOne(
            "SELECT COUNT(*) as count, AVG(rating) as average 
             FROM recipe_comments 
             WHERE recipe_id = :recipe_id AND rating IS NOT NULL",
            ['recipe_id' => $recipeId]
        );

        return [
            'count' => $result['count'] ?? 0,
            'average' => round($result['average'] ?? 0, 1)
        ];
    }

    // ===== АКТИВНОСТЬ И ПОДПИСКИ =====

    /**
     * Подписаться на пользователя
     */
    public function followUser(int $userId, int $userToFollowId): bool
    {
        return $this->addFriend($userId, $userToFollowId);
    }

    /**
     * Отписаться от пользователя
     */
    public function unfollowUser(int $userId, int $userToUnfollowId): bool
    {
        return $this->removeFriend($userId, $userToUnfollowId);
    }

    /**
     * Получить ленту активности друзей
     */
    public function getFriendsFeed(int $userId, int $limit = 20): array
    {
        $friends = $this->db->query(
            "SELECT DISTINCT friend_id FROM friends 
             WHERE user_id = :user_id AND status = 'accepted'
             UNION
             SELECT DISTINCT user_id FROM friends 
             WHERE friend_id = :user_id AND status = 'accepted'",
            ['user_id' => $userId]
        );

        $friendIds = array_map(fn($f) => $f['friend_id'] ?? $f['user_id'], $friends);

        if (empty($friendIds)) {
            return [];
        }

        $placeholders = implode(',', $friendIds);

        return $this->db->query(
            "SELECT r.*, u.username, u.avatar_url,
                    (SELECT COUNT(*) FROM favorites WHERE recipe_id = r.id) as favorites_count
             FROM recipes r
             JOIN users u ON r.user_id = u.id
             WHERE r.user_id IN ($placeholders) AND r.is_published = TRUE
             ORDER BY r.created_at DESC
             LIMIT $limit"
        );
    }

    /**
     * Получить популярные пользователи
     */
    public function getPopularUsers(int $limit = 10): array
    {
        return $this->db->query(
            "SELECT u.id, u.username, u.avatar_url, u.bio,
                    COUNT(DISTINCT r.id) as recipe_count,
                    COUNT(DISTINCT f.friend_id) as followers_count
             FROM users u
             LEFT JOIN recipes r ON u.id = r.user_id
             LEFT JOIN friends f ON u.id = f.friend_id AND f.status = 'accepted'
             WHERE u.is_active = TRUE
             GROUP BY u.id
             ORDER BY recipe_count DESC, followers_count DESC
             LIMIT :limit",
            ['limit' => $limit]
        );
    }

    /**
     * Получить рецепты от друзей
     */
    public function getFriendsRecipes(int $userId, int $limit = 20, int $offset = 0): array
    {
        $friends = $this->getFriends($userId);
        $friendIds = array_map(fn($f) => $f['id'], $friends);

        if (empty($friendIds)) {
            return [];
        }

        $placeholders = implode(',', $friendIds);

        return $this->db->query(
            "SELECT r.*, u.username, u.avatar_url
             FROM recipes r
             JOIN users u ON r.user_id = u.id
             WHERE r.user_id IN ($placeholders) AND r.is_published = TRUE
             ORDER BY r.created_at DESC
             LIMIT $limit OFFSET $offset"
        );
    }

    /**
     * Получить статистику пользователя
     */
    public function getUserStats(int $userId): array
    {
        return $this->db->queryOne(
            "SELECT 
                (SELECT COUNT(*) FROM recipes WHERE user_id = :user_id) as recipes_count,
                (SELECT COUNT(*) FROM favorites WHERE user_id = :user_id) as favorites_count,
                (SELECT COUNT(*) FROM friends WHERE (user_id = :user_id OR friend_id = :user_id) AND status = 'accepted') as friends_count,
                (SELECT COUNT(*) FROM community_members WHERE user_id = :user_id) as communities_count,
                (SELECT COUNT(*) FROM recipe_comments WHERE user_id = :user_id) as comments_count,
                (SELECT SUM(views_count) FROM recipes WHERE user_id = :user_id) as total_views
             FROM users WHERE id = :user_id",
            ['user_id' => $userId]
        );
    }

    /**
     * Получить активности сообщества
     */
    public function getCommunityActivity(int $communityId, int $limit = 50): array
    {
        return $this->db->query(
            "SELECT r.id, r.title, r.created_at, u.username, u.avatar_url,
                    'recipe_added' as activity_type
             FROM recipes r
             JOIN users u ON r.user_id = u.id
             JOIN community_members cm ON u.id = cm.user_id
             WHERE cm.community_id = :community_id AND r.is_published = TRUE
             ORDER BY r.created_at DESC
             LIMIT :limit",
            ['community_id' => $communityId, 'limit' => $limit]
        );
    }

    // ===== БЛОКИРОВКИ =====

    /**
     * Заблокировать пользователя
     */
    public function blockUser(int $userId, int $blockUserId): bool
    {
        return $this->db->execute(
            "INSERT INTO friends (user_id, friend_id, status) 
             VALUES (:user_id, :block_user_id, 'blocked')
             ON DUPLICATE KEY UPDATE status = 'blocked'",
            ['user_id' => $userId, 'block_user_id' => $blockUserId]
        );
    }

    /**
     * Проверить, заблокирован ли пользователь
     */
    public function isBlocked(int $userId, int $checkUserId): bool
    {
        $result = $this->db->queryOne(
            "SELECT id FROM friends 
             WHERE user_id = :user_id AND friend_id = :check_user_id AND status = 'blocked'",
            ['user_id' => $userId, 'check_user_id' => $checkUserId]
        );

        return $result !== null;
    }

    /**
     * Разблокировать пользователя
     */
    public function unblockUser(int $userId, int $blockedUserId): bool
    {
        return $this->db->execute(
            "DELETE FROM friends 
             WHERE user_id = :user_id AND friend_id = :blocked_user_id AND status = 'blocked'",
            ['user_id' => $userId, 'blocked_user_id' => $blockedUserId]
        );
    }
}
?>