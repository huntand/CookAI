<?php

namespace Core;

class Router
{
    private array $routes = [];
    private array $params = [];

    /**
     * Зарегистрировать GET маршрут
     */
    public function get($path, $callback)
    {
        $this->register('GET', $path, $callback);
    }

    /**
     * Зарегистрировать POST маршрут
     */
    public function post($path, $callback)
    {
        $this->register('POST', $path, $callback);
    }

    /**
     * Зарегистрировать PUT маршрут
     */
    public function put($path, $callback)
    {
        $this->register('PUT', $path, $callback);
    }

    /**
     * Зарегистрировать DELETE маршрут
     */
    public function delete($path, $callback)
    {
        $this->register('DELETE', $path, $callback);
    }

    /**
     * Зарегистрировать маршрут
     */
    private function register($method, $path, $callback)
    {
        $pattern = $this->convertToRegex($path);
        $this->routes[$method][$pattern] = $callback;
    }

    /**
     * Обработать запрос
     */
    public function handle($method, $uri)
    {
        // Удалить query string
        $uri = parse_url($uri, PHP_URL_PATH);

        $routes = $this->routes[$method] ?? [];

        foreach ($routes as $pattern => $callback) {
            if (preg_match($pattern, $uri, $matches)) {
                array_shift($matches); // Удалить полное совпадение

                echo $callback(...$matches);
                return;
            }
        }

        // Маршрут не найден
        http_response_code(404);
        echo json_encode(['error' => 'Route not found']);
    }

    /**
     * Преобразовать путь в регулярное выражение
     */
    private function convertToRegex($path): string
    {
        $pattern = preg_replace_callback('/:(\w+)/', function ($matches) {
            return '(\w+)';
        }, $path);

        return '#^' . $pattern . '$#';
    }
}
?>