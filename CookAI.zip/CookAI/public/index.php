<?php
session_start();
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Автозагрузка классов
spl_autoload_register(function ($class) {
    $file = __DIR__ . '/../app/' . str_replace('\\', '/', $class) . '.php';
    if (file_exists($file)) require $file;
});

// Подключение конфигурации
$config = require __DIR__ . '/../config/app.php';
$dbConfig = require __DIR__ . '/../config/database.php';

// Инициализация БД
use Core\Database;
$db = new Database($dbConfig);

// Маршрутизация
use Core\Router;
$router = new Router();

// Определение маршрутов
$uri = parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH);
$uri = str_replace('/public', '', $uri);
$method = $_SERVER['REQUEST_METHOD'];

// public/index.php
$uri = $_SERVER['REQUEST_URI'];
$method = $_SERVER['REQUEST_METHOD'];

// Маршруты
if ($uri === '/' && $method === 'GET') {
    $controller = new HomeController($db);
    echo $controller->index();
} elseif ($uri === '/recipes' && $method === 'GET') {
    $controller = new HomeController($db);
    echo $controller->allRecipes();
} elseif (preg_match('/^\/recipe\/(\d+)$/', $uri, $m)) {
    $controller = new RecipeController($db);
    echo $controller->show($m[1]);
} elseif ($uri === '/recipe/create' && $method === 'GET') {
    $controller = new RecipeController($db);
    echo $controller->create();
} elseif ($uri === '/recipe/store' && $method === 'POST') {
    $controller = new RecipeController($db);
    echo $controller->store();
} elseif ($uri === '/admin' && $method === 'GET') {
    $controller = new AdminController($db);
    echo $controller->dashboard();
} elseif ($uri === '/api/ai/generate-recipe' && $method === 'POST') {
    $controller = new AIController($db);
    echo $controller->generateRecipe();
} elseif ($uri === '/api/ai/scan-food' && $method === 'POST') {
    $controller = new AIController($db);
    echo $controller->scanFood();
}

// ===== ИНИЦИАЛИЗАЦИЯ =====

session_start();

// Загрузить переменные окружения
if (file_exists(__DIR__ . '/../.env')) {
    $envFile = file_get_contents(__DIR__ . '/../.env');
    foreach (explode("\n", $envFile) as $line) {
        if (empty($line) || strpos($line, '#') === 0) continue;
        list($key, $value) = explode('=', $line, 2);
        $_ENV[trim($key)] = trim($value);
    }
}

// Автозагрузка
require_once __DIR__ . '/../vendor/autoload.php';

use Core\Database;
use Core\Router;
use Routes\ApiRouter;

// ===== ИНИЦИАЛИЗАЦИЯ БД =====

$db = new Database([
    'host' => $_ENV['DB_HOST'] ?? 'localhost',
    'user' => $_ENV['DB_USER'] ?? 'root',
    'password' => $_ENV['DB_PASSWORD'] ?? '',
    'database' => $_ENV['DB_NAME'] ?? 'cookai'
]);

// ===== ИНИЦИАЛИЗАЦИЯ МАРШРУТИЗАТОРА =====

$router = new Router();

// Регистрация API маршрутов
$apiRouter = new ApiRouter($router, $db);
$apiRouter->register();

// ===== ОБРАБОТКА ЗАПРОСА =====

try {
    $uri = parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH);
    $method = $_SERVER['REQUEST_METHOD'];
    
    // CORS заголовки (для AJAX запросов)
    header('Access-Control-Allow-Origin: *');
    header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS');
    header('Access-Control-Allow-Headers: Content-Type, Authorization, X-Requested-With, X-CSRF-Token');
    header('Content-Type: application/json; charset=utf-8');

    // Обработать запрос
    $router->handle($method, $uri);

} catch (\Exception $e) {
    http_response_code(500);
    echo json_encode([
        'error' => 'Internal Server Error',
        'message' => $_ENV['APP_DEBUG'] ? $e->getMessage() : 'An error occurred'
    ]);
}
?>