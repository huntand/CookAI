// ===== AI TOOLS =====
const AITools = {
    // Сканер калорий
    initFoodScanner() {
        const form = document.getElementById('food-scanner-form');
        if (!form) return;
        
        form.addEventListener('submit', async (e) => {
            e.preventDefault();
            
            const formData = new FormData(form);
            const file = formData.get('image');
            
            if (!file) {
                APP.showNotification('Пожалуйста, выберите изображение', 'warning');
                return;
            }
            
            // Проверка типа файла
            if (!file.type.startsWith('image/')) {
                APP.showNotification('Пожалуйста, загрузите изображение', 'error');
                return;
            }
            
            // Загрузка с отслеживанием прогресса
            this.uploadAndAnalyze(file);
        });
    },
    
    async uploadAndAnalyze(file) {
        const formData = new FormData();
        formData.append('image', file);
        
        try {
            // Показать спиннер
            const resultDiv = document.getElementById('scan-result');
            if (resultDiv) {
                resultDiv.innerHTML = '<div class="spinner"></div><p>Анализирую фото...</p>';
            }
            
            const response = await fetch('/api/ai/scan-food', {
                method: 'POST',
                body: formData,
                headers: {
                    'X-CSRF-Token': APP.csrfToken
                }
            });
            
            if (!response.ok) throw new Error('Ошибка сканирования');
            
            const result = await response.json();
            this.displayScanResult(result);
        } catch (error) {
            console.error('Ошибка:', error);
            APP.showNotification('Не удалось проанализировать фото', 'error');
        }
    },
    
    displayScanResult(result) {
        const resultDiv = document.getElementById('scan-result');
        if (!resultDiv) return;
        
        const html = `
            <div style="background: #f0f9ff; padding: 20px; border-radius: 12px;">
                <h3>Результаты сканирования:</h3>
                <table style="width: 100%; margin-top: 15px;">
                    <tr>
                        <td><strong>Калории:</strong></td>
                        <td>${result.calories || 0} kcal</td>
                    </tr>
                    <tr>
                        <td><strong>Белки:</strong></td>
                        <td>${result.proteins || 0} g</td>
                    </tr>
                    <tr>
                        <td><strong>Жиры:</strong></td>
                        <td>${result.fats || 0} g</td>
                    </tr>
                    <tr>
                        <td><strong>Углеводы:</strong></td>
                        <td>${result.carbs || 0} g</td>
                    </tr>
                </table>
                <p style="margin-top: 15px;"><strong>Распознанные ингредиенты:</strong></p>
                <ul>
                    ${(result.ingredients || []).map(ing => `<li>${ing}</li>`).join('')}
                </ul>
            </div>
        `;
        
        resultDiv.innerHTML = html;
        APP.showNotification('Фото успешно проанализировано!', 'success');
    },
    
    // Генератор рецептов
    initRecipeGenerator() {
        const form = document.getElementById('recipe-generator-form');
        if (!form) return;
        
        form.addEventListener('submit', async (e) => {
            e.preventDefault();
            
            const formData = new FormData(form);
            const data = {
                diet: formData.get('diet'),
                time: formData.get('time'),
                ingredients: formData.get('ingredients').split(',').map(i => i.trim()),
                servings: formData.get('servings') || 2
            };
            
            await this.generateRecipe(data);
        });
    },
    
    async generateRecipe(params) {
        try {
            const resultDiv = document.getElementById('generated-recipe');
            if (resultDiv) {
                resultDiv.innerHTML = '<div class="spinner"></div><p>Генерирую рецепт...</p>';
            }
            
            const response = await fetch('/api/ai/generate-recipe', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'X-CSRF-Token': APP.csrfToken
                },
                body: JSON.stringify(params)
            });
            
            if (!response.ok) throw new Error('Ошибка генерации');
            
            const recipe = await response.json();
            this.displayGeneratedRecipe(recipe);
        } catch (error) {
            console.error('Ошибка:', error);
            APP.showNotification('Не удалось сгенерировать рецепт', 'error');
        }
    },
    
    displayGeneratedRecipe(recipe) {
        const resultDiv = document.getElementById('generated-recipe');
        if (!resultDiv) return;
        
        const html = `
            <div style="background: white; padding: 30px; border-radius: 12px;">
                <h2>${recipe.name}</h2>
                <p style="color: #666; margin-bottom: 20px;">${recipe.description}</p>
                
                <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 30px;">
                    <div>
                        <h4>Ингредиенты:</h4>
                        <ul>
                            ${recipe.ingredients.map(ing => `<li>${ing}</li>`).join('')}
                        </ul>
                    </div>
                    <div>
                        <h4>Питательная ценность на порцию:</h4>
                        <ul>
                            <li>Калории: ${recipe.nutrition.calories}</li>
                            <li>Белки: ${recipe.nutrition.proteins}g</li>
                            <li>Жиры: ${recipe.nutrition.fats}g</li>
                            <li>Углеводы: ${recipe.nutrition.carbs}g</li>
                        </ul>
                    </div>
                </div>
                
                <h4 style="margin-top: 20px;">Инструкции приготовления:</h4>
                <ol>
                    ${recipe.instructions.map(inst => `<li>${inst}</li>`).join('')}
                </ol>
                
                <button class="btn btn-primary" onclick="AITools.saveRecipe('${recipe.id}')">
                    ❤️ Сохранить в избранное
                </button>
            </div>
        `;
        
        resultDiv.innerHTML = html;
    },
    
    async saveRecipe(recipeId) {
        try {
            const response = await fetch(`/api/recipes/${recipeId}/favorite`, {
                method: 'POST',
                headers: { 'X-CSRF-Token': APP.csrfToken }
            });
            
            if (response.ok) {
                APP.showNotification('Рецепт сохранён в избранное!', 'success');
            }
        } catch (error) {
            console.error('Ошибка:', error);
        }
    }
};

// Инициализация при загрузке
document.addEventListener('DOMContentLoaded', () => {
    AITools.initFoodScanner();
    AITools.initRecipeGenerator();
});