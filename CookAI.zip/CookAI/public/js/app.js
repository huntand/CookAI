// ===== ГЛОБАЛЬНАЯ КОНФИГУРАЦИЯ =====
const APP = {
    apiUrl: '/api',
    csrfToken: document.querySelector('meta[name="csrf-token"]')?.content || '',
    
    // Инициализация при загрузке страницы
    init() {
        this.setupEventListeners();
        this.setupAjax();
        this.loadUserData();
    },
    
    // Настройка слушателей событий
    setupEventListeners() {
        document.addEventListener('click', (e) => {
            // Закрытие модальных окон
            if (e.target.classList.contains('modal')) {
                this.closeModal(e.target.id);
            }
            
            // Кнопка закрытия модали
            if (e.target.classList.contains('modal-close')) {
                this.closeModal(e.target.closest('.modal').id);
            }
        });
    },
    
    // Настройка AJAX с CSRF-токеном
    setupAjax() {
        // Добавление CSRF-токена ко всем POST/PUT/DELETE запросам
        document.addEventListener('submit', (e) => {
            if (e.target.method.toUpperCase() === 'POST') {
                const token = document.querySelector('input[name="csrf_token"]');
                if (!token) {
                    const input = document.createElement('input');
                    input.type = 'hidden';
                    input.name = 'csrf_token';
                    input.value = this.csrfToken;
                    e.target.appendChild(input);
                }
            }
        });
    },
    
    // Загрузка данных пользователя
    loadUserData() {
        const user = sessionStorage.getItem('user');
        if (user) {
            try {
                const userData = JSON.parse(user);
                this.renderUserInfo(userData);
            } catch (e) {
                console.error('Ошибка парсинга данных пользователя:', e);
            }
        }
    },
    
    // Рендер информации о пользователе
    renderUserInfo(user) {
        const userElement = document.getElementById('user-info');
        if (userElement) {
            userElement.innerHTML = `Привет, ${user.name}!`;
        }
    },
    
    // Открытие модального окна
    openModal(modalId) {
        const modal = document.getElementById(modalId);
        if (modal) {
            modal.classList.add('show');
        }
    },
    
    // Закрытие модального окна
    closeModal(modalId) {
        const modal = document.getElementById(modalId);
        if (modal) {
            modal.classList.remove('show');
        }
    },
    
    // Показ уведомления
    showNotification(message, type = 'info') {
        const container = document.getElementById('notification-container');
        const alert = document.createElement('div');
        alert.className = `alert alert-${type}`;
        alert.innerHTML = message;
        alert.style.margin = '10px 0';
        
        if (container) {
            container.appendChild(alert);
            setTimeout(() => alert.remove(), 3000);
        }
    },
    
    // AJAX запрос
    async fetch(url, options = {}) {
        const method = options.method || 'GET';
        const headers = options.headers || {};
        headers['Content-Type'] = 'application/json';
        
        if (method !== 'GET') {
            headers['X-CSRF-Token'] = this.csrfToken;
        }
        
        try {
            const response = await fetch(url, {
                method,
                headers,
                body: options.body ? JSON.stringify(options.body) : undefined
            });
            
            if (!response.ok) {
                throw new Error(`HTTP ${response.status}`);
            }
            
            return await response.json();
        } catch (error) {
            console.error('Ошибка запроса:', error);
            this.showNotification('Ошибка при загрузке данных', 'error');
            throw error;
        }
    }
};

// Инициализация при загрузке DOM
document.addEventListener('DOMContentLoaded', () => APP.init());