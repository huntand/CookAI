-- Вставка пользователей
INSERT INTO users (username, email, password_hash, full_name, bio, diet_preference, daily_calories_goal) VALUES
('alice_chef', 'alice@example.com', '$2y$10$SALT_HASH_ALICE', 'Алиса Шефова', 'Любительница здоровой кухни', 'vegetarian', 2000),
('bob_foodlover', 'bob@example.com', '$2y$10$SALT_HASH_BOB', 'Боб Гурман', 'Готовлю итальянскую кухню', 'omnivore', 2500),
('carol_vegan', 'carol@example.com', '$2y$10$SALT_HASH_CAROL', 'Каролина Веган', 'Вегетарианка с 5-летним стажем', 'vegan', 1800),
('admin_cookai', 'admin@cookai.local', '$2y$10$SALT_HASH_ADMIN', 'Администратор', 'Админ CookAI', 'omnivore', 2200);

-- Вставка сообществ
INSERT INTO communities (name, description, category, admin_id, members_count) VALUES
('Веганская кухня', 'Сообщество для вегетарианцев и веганов', 'diet', 3, 150),
('Итальянская кухня', 'Обсуждаем классические итальянские блюда', 'cuisine', 2, 200),
('ПП и ЗОЖ', 'Здоровое питание и тренировки', 'health', 1, 300);

-- Вставка членов сообществ
INSERT INTO community_members (community_id, user_id, role) VALUES
(1, 1, 'member'),
(1, 3, 'member'),
(2, 2, 'moderator'),
(3, 1, 'moderator'),
(3, 2, 'member');

-- Вставка челленджей
INSERT INTO challenges (title, description, start_date, end_date, reward_points) VALUES
('30 дней ПП', 'Готовьте только здоровую еду в течение месяца', '2026-05-28', '2026-06-28', 500),
('Азиатская кухня', 'Приготовьте 5 блюд из азиатской кухни', '2026-05-28', '2026-06-11', 300),
('Завтраки чемпиона', 'Создайте и поделитесь 7 рецептами завтраков', '2026-06-01', '2026-06-07', 200);

-- Вставка рецептов
INSERT INTO recipes (user_id, title, description, prep_time, cook_time, servings, difficulty, diet_type, calories_per_serving, cuisine) VALUES
(1, 'Салат с авокадо и помидорами', 'Свежий и полезный салат на основе авокадо', 10, 0, 2, 'easy', 'vegan', 180, 'Mediterranean'),
(2, 'Паста Болоньезе', 'Классическое итальянское блюдо с говяжьим фаршем', 15, 30, 4, 'medium', 'omnivore', 450, 'Italian'),
(3, 'Тофу со специями', 'Хрустящий тофу с азиатскими специями', 20, 20, 2, 'medium', 'vegan', 220, 'Asian');