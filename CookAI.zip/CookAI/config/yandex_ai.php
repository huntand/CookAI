<?php

return [
    'gpt_key' => $_ENV['YANDEX_GPT_KEY'] ?? 'your-gpt-key',
    'vision_key' => $_ENV['YANDEX_VISION_KEY'] ?? 'your-vision-key',
    'image_gen_key' => $_ENV['YANDEX_IMAGE_GEN_KEY'] ?? 'your-image-gen-key',
    'folder_id' => $_ENV['YANDEX_FOLDER_ID'] ?? 'your-folder-id'
];
?>