# CookAI — Интеллектуальная кулинарная платформа

![CookAI](https://img.shields.io/badge/PHP-8.0+-blue) ![MySQL](https://img.shields.io/badge/MySQL-InnoDB-green) ![License](https://img.shields.io/badge/License-MIT-yellow)

## 📋 Описание

**CookAI** — полнофункциональное веб-приложение для автоматизации кулинарных задач с помощью AI. Платформа позволяет пользователям генерировать рецепты, анализировать блюда по фото, создавать планы питания и участвовать в интерактивном кулинарном сообществе.

### Основные возможности:
- 🤖 **AI-инструменты**: генератор рецептов, сканер калорий, советник по готовке
- 📱 **Личный кабинет**: план питания, кулинарные книги, избранное
- 👥 **Социальная сеть**: сообщества, друзья, чат, челленджи, рейтинги
- 🎨 **Минималистичный дизайн** в стиле CookAI с адаптивной вёрсткой

## 🛠 Требования

- **PHP**: 8.0 или выше
- **MySQL**: 5.7+ (рекомендуется 8.0)
- **Веб-сервер**: Apache с поддержкой `.htaccess` и `mod_rewrite`
- **API-ключи**: Yandex AI Studio (GPT, Image Generation, Computer Vision)

## 📦 Установка

### 1. Скачивание и загрузка на хостинг

```bash
# Распаковать архив в public_html
unzip CookAI.zip -d public_html/

# Структура:
public_html/
├── app/
├── public/
├── config/
├── database/
└── storage/

Создание базы данных

# Подключиться к MySQL
mysql -u root -p

# Создать БД
CREATE DATABASE cookai CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

# Импортировать схему
mysql -u root -p cookai < database/schema.sql

# Загрузить тестовые данные (опционально)
mysql -u root -p cookai < database/fixtures.sql

Права доступа

chmod 755 storage/
chmod 755 storage/uploads/
chmod 644 public/.htaccess

Структура проекта

CookAI/
├── app/
│   ├── controllers/          # Обработчики маршрутов
│   │   ├── HomeController.php
│   │   ├── RecipeController.php
│   │   ├── AIController.php
│   │   ├── UserController.php
│   │   ├── SocialController.php
│   │   ├── AdminController.php
│   │   └── APIController.php
│   ├── models/               # Модели данных
│   │   ├── User.php
│   │   ├── Recipe.php
│   │   ├── Community.php
│   │   ├── Challenge.php
│   │   └── Message.php
│   ├── views/                # Шаблоны Blade-подобный синтаксис
│   │   ├── layouts/
│   │   ├── recipes/
│   │   ├── ai/
│   │   ├── social/
│   │   └── admin/
│   ├── services/             # Сервисы (AI, кэширование и т.д.)
│   │   ├── YandexAIService.php
│   │   ├── RecipeService.php
│   │   └── CacheService.php
│   └── middleware/           # Middleware для авторизации
│       ├── AuthMiddleware.php
│       └── AdminMiddleware.php
├── public/
│   ├── index.php             # Точка входа
│   ├── .htaccess             # Переписывание URL
│   ├── css/
│   │   ├── style.css         # Основные стили (дизайн CookAI)
│   │   └── responsive.css
│   ├── js/
│   │   ├── app.js
│   │   ├── ai-tools.js
│   │   └── social.js
│   └── img/
│       └── icons/
├── config/
│   ├── app.php               # Основная конфигурация
│   ├── database.php
│   └── yandex_ai.php
├── database/
│   ├── schema.sql            # Структура БД
│   └── fixtures.sql          # Тестовые данные
├── storage/
│   └── uploads/              # Загруженные файлы
├── tests/                    # Unit-тесты
└── .gitignore